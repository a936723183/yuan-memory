window.__ModuleLoader__.load({
  id: 'dsh-memory-library',
  factory: require => {
    const React = require('react');
    const h = React.createElement;
    const BASE = 'http://127.0.0.1:18766';

    async function call(path, body) {
      const res = await fetch(BASE + path, body === undefined ? { cache: 'no-store' } : {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), cache: 'no-store',
      });
      let data = {};
      try { data = await res.json(); } catch { /* ignore */ }
      if (!res.ok) throw new Error(data.error || ('HTTP ' + res.status));
      return data;
    }

    const row = { display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 8 };
    const input = {
      font: 'inherit', color: 'var(--dsw-alias-label-primary)', background: 'var(--dsw-alias-bg-base)',
      border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 8, padding: '7px 9px', minWidth: 260,
    };
    const btn = { font: 'inherit', padding: '7px 12px', borderRadius: 8, cursor: 'pointer' };
    const muted = { color: 'var(--dsw-alias-label-tertiary)', fontSize: 13, margin: '4px 0' };
    const okText = { color: 'var(--dsw-alias-label-primary)', fontSize: 13, margin: '6px 0', whiteSpace: 'pre-wrap' };

    function SettingsPage() {
      const [status, setStatus] = React.useState(null);
      const [key, setKey] = React.useState('');
      const [note, setNote] = React.useState('');
      const [busy, setBusy] = React.useState(false);
      const [batch, setBatch] = React.useState(60);

      const load = React.useCallback(async () => {
        try { setStatus(await call('/api/status')); }
        catch (err) { setNote('连不上本机服务：' + String(err.message || err)); }
      }, []);
      React.useEffect(() => { void load(); }, [load]);

      async function run(fn, label) {
        setBusy(true); setNote(label + '…');
        try { const out = await fn(); setNote(label + '：' + (out?.summary || out?.out || '完成')); }
        catch (err) { setNote(label + '失败：' + String(err.message || err)); }
        finally { setBusy(false); void load(); }
      }

      const v = status?.vector || {};
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
        h('p', { style: muted }, '记忆卡是唯一真相；这里只管派生层（图书馆 qq_zone）的同步、检索和限量向量回填。'),
        h('p', { style: muted }, status
          ? `Key：${status.apiKeySet ? '已设置 ' + status.apiKeyHint : '未设置'} · 区域 ${status.region} · 模型 ${status.model} · 向量 ${v.enabled ? '开' : '关'}${v.ondemand_active ? '（窗口开）' : ''} · 待同步 ${status.pendingCardRecords} 条`
          : '读取状态中…'),

        h('div', { style: row },
          h('input', {
            style: input, type: 'password', placeholder: '硅基流动 Key（sk-…，只存本机，不回显）',
            value: key, onChange: e => setKey(e.target.value), 'aria-label': '硅基流动 API Key',
          }),
          h('button', {
            style: btn, disabled: busy || !key.trim(),
            onClick: () => run(async () => { const r = await call('/api/key', { apiKey: key.trim() }); setKey(''); return r; }, '保存 Key'),
          }, '保存 Key')),

        h('div', { style: row },
          h('button', { style: btn, disabled: busy, onClick: () => run(() => call('/api/sync', {}), '同步记忆卡') }, '同步记忆卡'),
          h('button', {
            style: btn, disabled: busy,
            onClick: () => run(() => call('/api/embed', { limit: Number(batch) || 60 }), '向量回填'),
          }, '向量回填一批'),
          h('input', {
            style: { ...input, minWidth: 80, width: 90 }, type: 'number', min: 1, max: 500, value: batch,
            onChange: e => setBatch(e.target.value), 'aria-label': '每批条数',
          }),
          h('span', { style: muted }, '条/批（开窗 10 分钟自动关）')),

        note ? h('p', { style: okText }, note) : null,
        h('p', { style: muted }, 'Key 只保存在本机配置文件，页面与接口只回显后 4 位；卸载插件不影响记忆卡。'),
      );
    }

    function apply(ctx) {
      try {
        ctx.slots.inject('settings.section', () => ctx.slots.register({
          name: 'settings.section', id: 'memory-library', order: 21, label: () => '记忆图书馆',
        }, SettingsPage));
      } catch (err) {
        try { console.warn('[memory-library] 注册设置卡片失败：', err); } catch { /* ignore */ }
      }
    }

    return { name: 'memory-library-settings', inject: ['slots'], apply, SettingsPage };
  },
});

/** 自查：插件内核（配置、页面、状态、key 不泄漏）。不会真的调用 embedding。 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as lib from './lib.mjs';

const server = lib.startServer(0);
await new Promise((r) => server.once('listening', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}`;

let n = 0;
const ok = (name, fn) => { fn(); n += 1; console.log(`  ✓ ${name}`); };

// 1) 页面
const page = await fetch(base + '/');
ok('页面 200', () => assert.equal(page.status, 200));
const html = await page.text();
ok('页面含表单', () => assert.ok(html.includes('硅基流动') && html.includes('api/key')));

// 2) 状态
const st = await (await fetch(base + '/api/status')).json();
ok('状态有向量与待同步字段', () => {
  assert.ok('vector' in st);
  assert.ok('pendingCardRecords' in st);
});

// 3) 写 key（假 key，仅测试存储与脱敏）
const before = lib.loadConfig().apiKey;
const post = await (await fetch(base + '/api/key', {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ apiKey: 'sk-abcdefgh12345678' }),
})).json();
ok('保存 key 成功', () => assert.equal(post.ok, true));
ok('返回体不含完整 key', () => {
  const s = JSON.stringify(post);
  assert.ok(!s.includes('sk-abcdefgh12345678'));
  assert.ok(s.includes('5678'));
});
ok('配置落盘', () => assert.equal(lib.loadConfig().apiKey, 'sk-abcdefgh12345678'));

// 4) 日志不得含 key
const log = fs.existsSync('plugin.log') ? fs.readFileSync('plugin.log', 'utf8') : '';
ok('日志不含 key', () => assert.ok(!log.includes('sk-abcdefgh12345678')));

// 5) 非法 key 被拒
const bad = await (await fetch(base + '/api/key', {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ apiKey: 'not-a-key' }),
})).json();
ok('非法 key 被拒', () => assert.equal(bad.ok, false));

// 6) 配置更新
const cfg = await (await fetch(base + '/api/config', {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ embedBatch: 30 }),
})).json();
ok('embedBatch 更新', () => assert.equal(cfg.embedBatch, 30));

// 复原
lib.saveConfig({ apiKey: before });
server.close();
n += 1;
console.log(`\nplugin lib: ${n} 项通过`);

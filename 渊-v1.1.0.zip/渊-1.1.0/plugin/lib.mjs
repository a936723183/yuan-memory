/**
 * 记忆图书馆 · 插件内核（可独立测试）
 *
 * 设计约束（与 2026-11-13 的分层方案一致）：
 *   · 记忆卡是唯一真相，这里只调用 card_import.py 做单向同步；
 *   · 图书馆是派生层，可 rebuild、可删；
 *   · 硅基流动的 key 只落在本机配置文件里，**不打印、不进日志、不回显**，
 *     只在调用 python 时作为环境变量传入（进程级，不落盘到 python 侧）。
 */
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const PLUGIN_DIR = HERE;
export const ROOT = process.env.MEM_ROOT || path.resolve(PLUGIN_DIR, '..', 'data', 'library');
export const LIB = process.env.MEM_LIB || path.resolve(PLUGIN_DIR, '..', 'library');
const CONFIG_PATH = path.join(PLUGIN_DIR, 'config.json');
const LOG_PATH = path.join(PLUGIN_DIR, 'plugin.log');
const PORT = Number(process.env.MEM_LIB_PORT || 18766);
const HOST = '127.0.0.1';

const DEFAULTS = Object.freeze({
  apiKey: '',
  model: 'BAAI/bge-m3',
  region: 'qq_zone',
  embedBatch: 60,
  autoSyncMinutes: 0,
  searchUseVector: true,
});

/** DSH 宿主进程的 PATH 里不一定有 python：优先用本机已知解释器。 */
function resolvePython() {
  const cands = [process.env.MEM_LIB_PYTHON, 'E:\\6deepseek\\python\\python.exe', 'python'].filter(Boolean);
  for (const c of cands) {
    if (c === 'python') return c;
    try { if (fs.existsSync(c)) return c; } catch { /* ignore */ }
  }
  return 'python';
}
export const PYTHON = resolvePython();

export function loadConfig() {
  try {
    const raw = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    return { ...DEFAULTS, ...raw };
  } catch {
    return { ...DEFAULTS };
  }
}

export function saveConfig(patch = {}) {
  const next = { ...loadConfig(), ...patch };
  fs.mkdirSync(PLUGIN_DIR, { recursive: true });
  const tmp = `${CONFIG_PATH}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(next, null, 2), 'utf8');
  try { fs.chmodSync(tmp, 0o600); } catch { /* Windows 上无意义 */ }
  fs.renameSync(tmp, CONFIG_PATH);
  // Windows：尽量只给当前用户（失败不影响功能，只记日志）
  try {
    execFile('icacls', [CONFIG_PATH, '/inheritance:r', '/grant', `${os.userInfo().username}:F`],
      { windowsHide: true, timeout: 5000 }, () => {});
  } catch { /* ignore */ }
  return publicConfig(next);
}

/** 对外展示用：绝不返回 key 本体，只说有没有。 */
export function publicConfig(cfg = loadConfig()) {
  return {
    apiKeySet: Boolean(cfg.apiKey),
    apiKeyHint: cfg.apiKey ? `sk-…${String(cfg.apiKey).slice(-4)}` : '',
    model: cfg.model,
    region: cfg.region,
    embedBatch: cfg.embedBatch,
    autoSyncMinutes: cfg.autoSyncMinutes,
    searchUseVector: cfg.searchUseVector,
  };
}

function log(line) {
  try {
    fs.mkdirSync(PLUGIN_DIR, { recursive: true });
    fs.appendFileSync(LOG_PATH, `[${new Date().toISOString()}] ${line}\n`, 'utf8');
  } catch { /* ignore */ }
}

/** 跑一条 python（默认不带 key；只有向量相关调用才注入） */
export function runPython(args, { withVector = false, timeoutMs = 180000 } = {}) {
  const cfg = loadConfig();
  const env = { ...process.env, PYTHONIOENCODING: 'utf-8', MEM_ROOT: ROOT };
  if (withVector) {
    if (cfg.apiKey) env.SILICONFLOW_API_KEY = cfg.apiKey;
    env.VECTORS_ENABLED = '1';
    env.MEM_EMBEDDING_MODEL = cfg.model;
  }
  return new Promise((resolve) => {
    execFile(PYTHON, args, { cwd: ROOT, env, windowsHide: true, timeout: timeoutMs, maxBuffer: 8 << 20 },
      (err, stdout, stderr) => {
        const code = err ? (typeof err.code === 'number' ? err.code : -1) : 0;
        if (code !== 0) log(`python ${args.join(' ')} → ${code}: ${String(stderr).slice(0, 300)}`);
        resolve({ code, stdout: String(stdout || ''), stderr: String(stderr || '') });
      });
  });
}

function py(name) { return path.join(LIB, name); }

export async function status() {
  const cfg = publicConfig();
  const vec = await runPython([py('memlib.py'), 'vec', 'status'], { withVector: false, timeoutMs: 20000 });
  let stats = {};
  try { stats = JSON.parse(vec.stdout.trim().split('\n').pop() || '{}'); } catch { /* ignore */ }
  const card = await runPython([py('card_import.py'), '--dry-run'], { timeoutMs: 60000 });
  const cardLine = (card.stdout.match(/待导入\s*(\d+)/) || [])[1] || '?';
  return { ...cfg, vector: stats, pendingCardRecords: cardLine, logTail: tailLog(5) };
}

export async function syncCard() {
  const r = await runPython([py('card_import.py')], { timeoutMs: 180000 });
  return { ok: r.code === 0, out: r.stdout.trim().split('\n').slice(-2).join(' / '), err: r.stderr.slice(0, 200) };
}

export async function search(query, { top = 5 } = {}) {
  const cfg = loadConfig();
  const withVector = cfg.searchUseVector && Boolean(cfg.apiKey);
  const args = [py('memlib.py'), 'search', String(query), '--region', cfg.region, '--top', String(top)];
  const r = await runPython(args, { withVector, timeoutMs: 60000 });
  if (r.code !== 0) return { ok: false, error: (r.stderr || '检索失败').slice(0, 300) };
  return { ok: true, text: r.stdout.trim() };
}

/** 限量向量：开窗 → 分批 embed → 关窗。只嵌这一批，不碰别的区。 */
export async function embedLimited(limit = 0) {
  const cfg = loadConfig();
  if (!cfg.apiKey) return { ok: false, error: '还没填硅基流动的 key（在插件页面填）' };
  const n = Math.max(1, Math.min(500, limit || cfg.embedBatch));
  await runPython([py('memlib.py'), 'vec', 'on', '--minutes', '10'], { withVector: true, timeoutMs: 30000 });
  try {
    const r = await runPython([py('memlib.py'), 'embed', '--region', cfg.region, '--limit', String(n)], { withVector: true, timeoutMs: 300000 });
    if (r.code !== 0) return { ok: false, error: (r.stderr || 'embed 失败').slice(0, 300) };
    return { ok: true, out: r.stdout.trim().split('\n').slice(-3).join(' / ') };
  } finally {
    await runPython([py('memlib.py'), 'vec', 'off'], { timeoutMs: 20000 });
  }
}

function tailLog(n) {
  try {
    return fs.readFileSync(LOG_PATH, 'utf8').trim().split('\n').slice(-n);
  } catch { return []; }
}

const PAGE = `<!doctype html><meta charset="utf-8"><title>记忆图书馆</title>
<style>body{font:14px/1.6 system-ui;max-width:720px;margin:40px auto;padding:0 16px;color:#222}
input,button,select{font:inherit;padding:6px 8px}h3{margin-top:28px}
pre{background:#f6f6f6;padding:10px;border-radius:6px;white-space:pre-wrap}
.hint{color:#666;font-size:12px}</style>
<h2>记忆图书馆 · 记忆卡同步</h2>
<p class="hint">记忆卡仍是唯一真相；这里是派生层（qq_zone），可随时 rebuild。</p>
<h3>硅基流动 Key</h3>
<input id="k" type="password" size="46" placeholder="sk-...（只存本机，不回显）">
<button onclick="saveKey()">保存</button> <span id="kh" class="hint"></span>
<h3>向量（限批）</h3>
<button onclick="embed()">回填一批</button> 每批 <input id="n" type="number" value="60" style="width:70px"> 条
<span class="hint">开窗 10 分钟后自动关闭</span>
<h3>状态</h3><pre id="st">加载中…</pre>
<script>
const api=(p,o)=>fetch(p,o).then(r=>r.json());
async function load(){const s=await api('/api/status');document.getElementById('kh').textContent=s.apiKeySet?('已设置 '+s.apiKeyHint):'未设置';document.getElementById('st').textContent=JSON.stringify(s,null,2);}
async function saveKey(){const k=document.getElementById('k').value.trim();if(!k)return;const r=await api('/api/key',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({apiKey:k})});document.getElementById('k').value='';alert(r.ok?'已保存':'失败：'+r.error);load();}
async function embed(){const n=+document.getElementById('n').value||60;const r=await api('/api/embed',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({limit:n})});alert(r.ok?'完成：'+(r.out||''):'失败：'+r.error);load();}
load();
</script>`;

export function createServer() {
  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');
    const origin = String(req.headers.origin || '');
    const originOk = !origin || /^https?:\/\/(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/i.test(origin) || /^dsh(-app)?:\/\//i.test(origin);
    const cors = {
      'access-control-allow-origin': originOk ? (origin || '*') : 'null',
      'access-control-allow-methods': 'GET,POST,OPTIONS',
      'access-control-allow-headers': 'content-type',
      'access-control-max-age': '600',
    };
    const send = (code, body, type = 'application/json') => {
      res.writeHead(code, { 'content-type': `${type}; charset=utf-8`, 'cache-control': 'no-store', ...cors });
      res.end(typeof body === 'string' ? body : JSON.stringify(body));
    };
    if (req.method === 'OPTIONS') return send(204, '');
    // 只允许本机访问
    const remote = req.socket.remoteAddress || '';
    if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(remote)) return send(403, { error: '只允许本机' });
    if (!originOk) return send(403, { error: '拒绝跨源请求' });

    try {
      if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) return send(200, PAGE, 'text/html');
      if (req.method === 'GET' && url.pathname === '/api/status') return send(200, await status());

      if (req.method === 'POST' && url.pathname === '/api/key') {
        const body = await readJson(req);
        const key = String(body?.apiKey || '').trim();
        if (!/^sk-[A-Za-z0-9_-]{8,}$/.test(key)) return send(400, { ok: false, error: '格式不像 sk- 开头的 key' });
        saveConfig({ apiKey: key });
        return send(200, { ok: true, ...publicConfig() });
      }
      if (req.method === 'POST' && url.pathname === '/api/config') {
        const body = await readJson(req);
        const patch = {};
        for (const k of ['model', 'region', 'embedBatch', 'searchUseVector']) if (k in (body || {})) patch[k] = body[k];
        return send(200, { ok: true, ...saveConfig(patch) });
      }
      if (req.method === 'POST' && url.pathname === '/api/sync') return send(200, await syncCard());

      if (req.method === 'POST' && url.pathname === '/api/embed') {
        const body = await readJson(req);
        return send(200, await embedLimited(Number(body?.limit) || 0));
      }
      return send(404, { error: 'not found' });
    } catch (err) {
      return send(500, { ok: false, error: String(err?.message || err).slice(0, 300) });
    }
  });
}

function readJson(req, limit = 65536) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

export function startServer(port = PORT) {
  const server = createServer();
  server.on('error', (err) => log(`server error: ${err?.message || err}`));
  server.listen(port, HOST, () => log(`listening http://${HOST}:${port}`));
  return server;
}

export { CONFIG_PATH, PAGE };

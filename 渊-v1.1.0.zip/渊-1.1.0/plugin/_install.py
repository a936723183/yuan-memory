# -*- coding: utf-8 -*-
"""把 dsh-memory-library 装进 desktop profile（可回滚）。

做了四件事：
  1) 备份 profile/package.json 与 cordis.patch.yml；
  2) package.json 加 link 依赖 + dsh.profile.bundles；
  3) 关掉之前手写的 file:// insert（避免重复加载）；
  4) node_modules 建 junction（等价 pnpm 的 link:）。
撤销：把两个 .bak-memlib-* 覆盖回去，删掉 node_modules\\dsh-memory-library。
"""
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

PROFILE = Path(os.environ["USERPROFILE"]) / ".dsh" / "profiles" / "desktop"
PKG = PROFILE / "package.json"
PATCH = PROFILE / "cordis.patch.yml"
LINK = PROFILE / "node_modules" / "dsh-memory-library"
SRC = str(Path(__file__).resolve().parent)
NAME = "dsh-memory-library"


def main() -> int:
    ts = time.strftime("%Y%m%d-%H%M%S")
    bak_pkg = PKG.with_name(f"package.json.bak-memlib-{ts}")
    bak_patch = PATCH.with_name(f"cordis.patch.yml.bak-memlib-{ts}")
    shutil.copy2(PKG, bak_pkg)
    shutil.copy2(PATCH, bak_patch)

    data = json.loads(PKG.read_text(encoding="utf-8"))
    deps = data.setdefault("dependencies", {})
    deps[NAME] = f"link:{SRC}"
    bundles = data.setdefault("dsh", {}).setdefault("profile", {}).setdefault("bundles", [])
    if NAME not in bundles:
        bundles.append(NAME)
    PKG.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    t = PATCH.read_text(encoding="utf-8")
    t2, n = re.subn(r"\n# === memory-library plugin BEGIN ===.*?# === memory-library plugin END ===\n",
                    "\n", t, flags=re.S)
    PATCH.write_text(t2, encoding="utf-8")

    if not LINK.exists():
        subprocess.run(["cmd", "/c", "mklink", "/J", str(LINK), SRC], check=True,
                       capture_output=True, text=True)

    print(f"依赖：{deps.get(NAME)}")
    print(f"bundles 含：{NAME in bundles}（共 {len(bundles)} 项）")
    print(f"手动 insert 已移除：{n} 处")
    print(f"junction：{'ok' if LINK.exists() else '缺失'}")
    print(f"备份：{bak_pkg.name} / {bak_patch.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

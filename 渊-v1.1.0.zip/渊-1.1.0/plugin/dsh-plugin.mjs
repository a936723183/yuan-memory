/**
 * 记忆图书馆 · DSH 插件入口
 *
 * 只做三件事：
 *   1) 把 记忆卡 → 图书馆(qq_zone) 的同步、检索、限量向量回填 暴露成工具；
 *   2) 起一个本机页面（http://127.0.0.1:18766）用来填硅基流动 key、看状态、点回填；
 *   3) 不碰记忆卡本体，不缓存任何记忆正文。
 */
import * as lib from './lib.mjs';

export const name = 'memory-library';
export const inject = ['tools'];

const URL_LINE = 'http://127.0.0.1:18766';

const empty = () => ({ type: 'object', properties: {}, additionalProperties: false });

const TOOLS = [
  {
    name: 'library_status',
    description: '记忆图书馆的状态：key 是否已设、向量开关、待同步的卡片条数。只读。',
    parameters: empty(),
    async execute() {
      const s = await lib.status();
      return {
        ok: true,
        page: URL_LINE,
        apiKeySet: s.apiKeySet,
        apiKeyHint: s.apiKeyHint,
        region: s.region,
        model: s.model,
        vector: s.vector,
        pendingCardRecords: s.pendingCardRecords,
      };
    },
  },
  {
    name: 'library_search',
    description: '在记忆图书馆里检索（默认 qq_zone = 角色的记忆）。字面 FTS 为主；配了 key 且开了向量窗口才做语义。',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', minLength: 1, maxLength: 300 },
        top: { type: 'integer', minimum: 1, maximum: 10 },
      },
      required: ['query'],
      additionalProperties: false,
    },
    async execute(args) {
      const r = await lib.search(args.query, { top: args.top || 5 });
      return r.ok ? { ok: true, results: r.text } : { ok: false, error: r.error };
    },
  },
  {
    name: 'library_sync',
    description: '把记忆卡增量同步进图书馆 qq_zone（只读卡、幂等）。记忆卡始终是唯一真相。',
    parameters: empty(),
    async execute() {
      const r = await lib.syncCard();
      return { ok: r.ok, summary: r.out, error: r.err || undefined };
    },
  },
  {
    name: 'library_embed',
    description: '限量向量回填：开窗 10 分钟、只嵌一批（默认 60 条）然后关窗。需要先在插件页填硅基流动 key。',
    parameters: {
      type: 'object',
      properties: { limit: { type: 'integer', minimum: 1, maximum: 500 } },
      additionalProperties: false,
    },
    async execute(args) {
      const r = await lib.embedLimited(args.limit || 0);
      return r.ok ? { ok: true, summary: r.out } : { ok: false, error: r.error };
    },
  },
  {
    name: 'library_config_page',
    description: '给出记忆图书馆的本机设置页地址（用来填硅基流动 key、看状态、点回填）。',
    parameters: empty(),
    async execute() {
      return { ok: true, url: URL_LINE, note: '仅本机可访问；key 只存本机配置文件，不回显。' };
    },
  },
];

export async function apply(ctx) {
  const disposers = [];
  for (const tool of TOOLS) {
    try { disposers.push(ctx.tools.register(tool)); }
    catch (err) { try { ctx.logger?.warn?.(`memory-library: 注册 ${tool.name} 失败 ${err?.message}`); } catch { /* ignore */ } }
  }

  let server;
  try {
    server = lib.startServer();
  } catch (err) {
    try { ctx.logger?.warn?.(`memory-library: 启动设置页失败 ${err?.message}`); } catch { /* ignore */ }
  }

  const dispose = () => {
    for (const d of disposers.splice(0)) { try { d?.(); } catch { /* ignore */ } }
    if (server) { try { server.close(); } catch { /* ignore */ } }
  };
  if (typeof ctx.effect === 'function') {
    try { ctx.effect(() => dispose); } catch { /* ignore */ }
  }
  if (typeof ctx.on === 'function') {
    try { ctx.on('dispose', dispose); } catch { /* ignore */ }
  }
}

export { TOOLS };

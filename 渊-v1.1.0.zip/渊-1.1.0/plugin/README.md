# 记忆图书馆 · DSH 插件

把「记忆卡 → 图书馆」的同步、检索、限量向量回填做成一键操作，并在设置里提供页面填硅基流动 Key。

## 装

```powershell
python _install.py     # 备份 profile 配置 → 加 link 依赖 + bundles → 建 junction
```

重启 DSH。设置里出现「记忆图书馆」。

卸载：覆盖回 `<profile>\package.json.bak-memlib-*` 与 `cordis.patch.yml.bak-memlib-*`，删掉
`<profile>\node_modules\dsh-memory-library`，再重启。

## 给什么

| 工具 | 说明 |
|---|---|
| `library_status` | key / 向量 / 待同步条数 |
| `library_search` | 区域检索（qq_zone 默认） |
| `library_sync` | 卡 → qq_zone（幂等，只读卡） |
| `library_embed` | 开窗 10 分钟、单批 60 条 |
| `library_config_page` | 设置页地址 |

设置页地址：`http://127.0.0.1:18766`（只绑本机，插件未加载时打不开属正常）。

## 安全边界

- Key 只落本机 `config.json`，尝试 `icacls` 限当前用户；
- 接口/页面只回显 `sk-…后4位`，日志不记 key；
- 服务只监听 `127.0.0.1`，并校验来源地址与 Origin；
- 插件不缓存任何记忆正文，也不碰记忆卡本体。

## 自测

```powershell
node test-plugin.mjs
```

覆盖：页面 200、状态字段、保存 key、响应不含完整 key、日志不含 key、非法 key 被拒、配置更新。

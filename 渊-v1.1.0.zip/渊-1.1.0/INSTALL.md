# 安装

> 三种深度：只试 → 日常用 → 接进 DSH。解压目录必须是 `渊-1.1.0` / `渊` / `yuan*`（名字锁要求）。

## 0. 环境

- **Python 3.9+**（用到 `sqlite3` + FTS5；官方发行版自带）
- 零第三方依赖（向量另需：硅基流动 key 或本地 Ollama）
- Windows 中文乱码：`chcp 65001` 或 `set PYTHONIOENCODING=utf-8`
- 插件要 **DSH 0.2.x**（只装核心则不需要 DSH）

验一下：

```powershell
cd 渊-1.1.0
python bin\name_lock.py verify      # 清单 ok / 目录 ok
```

---

## 1. 只试（5 分钟）

```powershell
$env:DSH_HOME = "$PWD\samples\home\.dsh"
python bin\yuan.py index
python bin\yuan.py recall "二元组 泛词" --top 3 --chars 400
python bin\qqcard.py --card samples\memory-card.sample.json recall "说好开刷" --top 2 --chars 200
```

样例是 10 条假记忆 + 1 张假卡，随便改、随便删。

---

## 2. 日常用（渊）

```powershell
$env:DSH_HOME = "$env:USERPROFILE\.dsh"   # 有 memories\ 就行
python bin\yuan.py index
python bin\yuan.py recall "上次那个方案" --top 3 --chars 600
```

想省事：把这行加进 `AGENTS.md` —— *"需要回忆过去时先跑 `yuan.py recall`，不要全量翻记忆文件。"*

---

## 3. 图书馆（可选）

```powershell
python library\memlib.py init                 # 建库到 data\library
python library\memlib.py update "试一条" --region dsh_zone
python library\memlib.py search "试一条" --region dsh_zone --top 3
```

接真实记忆卡：

```powershell
python library\card_import.py --dry-run
python library\card_import.py
```

向量（可选，先有 key 或本地模型）：

```powershell
$env:SILICONFLOW_API_KEY = 'sk-...'   # 不建议直接写进命令历史
$env:VECTORS_ENABLED = '1'
python library\memlib.py vec on --minutes 10
python library\memlib.py embed --region qq_zone --limit 60
python library\memlib.py vec off
```

---

## 4. 接进 DSH（插件）

```powershell
python plugin\_install.py
```

它会备份 profile 配置、加 `link:` 依赖与 bundles、建 junction。**重启 DSH** 后：

- 设置里出现 **「记忆图书馆」**：填 Key、看状态、同步、限量回填；
- 工具面多出 `library_status / library_search / library_sync / library_embed`。

卸载见 `USAGE.md` §6.3（一句话：覆盖回 `*.bak-memlib-*` + 删 junction）。

---

## 5. 接进 QQ 机器人（可选）

- **dsh-qqbot 扩展**：把 `integrations/dsh-qqbot/card_recall.mjs` 放进 `<bot 数据根>/.qqbot-extensions/tools/`，
  设 `QQ_CARD_SCRIPT=<包>\bin\qqcard.py`，发 `/tools-reload`。
  ⚠️ 能不能用还取决于该 bot 的工具面（有的 preset 只放行固定工具）。
- **surfcore 桥接注入**：按 `integrations/surfcore/HOOK.md` 放文件 + 三行接入，重启桥接。

---

## 6. 名字锁

```powershell
python bin\name_lock.py verify
python bin\name_lock.py unlock --root .
```

触发条件：清单被改（name/slug/签名）或目录名不含「渊」/不以 `yuan` 开头。
后果：写 `state/name-lock.json`、删索引库、退出码 3；**记忆源不删**。

---

## 7. 故障速查

| 现象 | 处理 |
|---|---|
| `no such module: fts5` | 换官方 Python |
| 召回全空 | `stats` 看条目；`index --force` |
| 退出码 3 | 名字锁，`unlock` + 目录改名 |
| 向量拒绝回填 | `VECTORS_ENABLED=1` 且配了 key |
| 设置页空白 | 重启 DSH；或开 `http://127.0.0.1:18766` |
| 插件装完启动异常 | 覆盖回 `*.bak-memlib-*`，删 junction |

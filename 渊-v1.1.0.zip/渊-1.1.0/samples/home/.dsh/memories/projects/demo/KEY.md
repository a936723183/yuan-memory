[2025-02-12 10:00] [shared]
示例项目关键记忆：入口是 bin/yuan.py，库在项目根目录，记忆源由 DSH_HOME 指向。

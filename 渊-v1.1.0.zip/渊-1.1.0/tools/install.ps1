# 渊 · Windows 一键铺开
#
# 用法（在解压出来的 渊-1.0.0 目录里，右键"用 PowerShell 运行"，或）：
#   powershell -ExecutionPolicy Bypass -File tools\install.ps1 -Target "$HOME\.local\share"
#
# 做的事：把整个包复制到 <Target>\渊，并在 <Target> 下建一个 yuan.cmd 快捷命令。
# 不写注册表、不动 PATH、不改任何记忆文件；卸载 = 删掉那个目录。

param(
  [string]$Target = "$HOME\.local\share",
  [switch]$Force
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $Target "渊"

Write-Host "源：$here"
Write-Host "目标：$dest"

if (Test-Path $dest) {
  if (-not $Force) {
    Write-Host "目标已存在。加 -Force 覆盖（会先备份成 渊.bak-<时间>）。" -ForegroundColor Yellow
    exit 1
  }
  $bak = "$dest.bak-$(Get-Date -Format yyyyMMdd-HHmmss)"
  Move-Item $dest $bak
  Write-Host "已备份：$bak"
}

New-Item -ItemType Directory -Force -Path $Target | Out-Null
Copy-Item $here $dest -Recurse

$shim = Join-Path $Target "yuan.cmd"
@"
@echo off
chcp 65001 >nul
python "$dest\bin\yuan.py" %*
"@ | Set-Content -Path $shim -Encoding ASCII

Write-Host ""
Write-Host "完成。" -ForegroundColor Green
Write-Host "  验证：python `"$dest\bin\name_lock.py`" verify"
Write-Host "  试跑：python `"$dest\bin\yuan.py`" index"
Write-Host "  快捷：把 $Target 加进 PATH 后可用  yuan recall `"上次那个方案`""
Write-Host ""
Write-Host "注意：目录名必须是「渊」；改名会触发名字锁（索引自毁、拒绝运行）。"

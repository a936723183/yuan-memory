/**
 * 记忆卡按句召回（实验性，2026-11-13）
 *
 * 背景：QQ 侧每轮只注入一张预渲染的记忆卡（≤2200 字），装不下的旧事永远想不起来，
 * 而她的工具面被 preset 锁死，加不了「记忆检索」工具。于是退一步：
 * **桥接在拼提示词时，按主人这句话去她的记忆卡里捞 1~2 条旧事，贴在记忆卡后面**。
 *
 * 边界：
 *   · 只读 memory-card.json，不写、不改、不影响记忆卡的渲染与衰减；
 *   · sensitive=true 的记录永不注入；
 *   · 只在「像在问旧事」或「字面命中很强」时注入，其余情况返回空串（零影响）；
 *   · 关闭方式：环境变量 SURFCORE_MEMORY_RECALL=0（或 =false/off）。
 *
 * 打分沿用「渊 / qqcard」那套：二元组 + IDF 覆盖率 + 重要度 + 新近度 + 类型/清晰度权重。
 */
import fs from 'node:fs';

const CJK_RUN = /[\u4e00-\u9fff]+/g;
const LATIN_WORD = /[A-Za-z0-9_]{2,}/g;

const QUERY_STOP = [
  '上次', '那个', '这个', '什么', '怎么', '如何', '为什么', '是不是', '可以', '帮我',
  '请问', '一下', '一些', '我们', '你们', '他们', '之前', '刚才', '记得', '还记得',
  '你说', '说过', '还是', '以及', '然后', '就是', '有没有', '还记',
];

const CLARITY_W = { vivid: 1.0, clear: 0.85, fuzzy: 0.6, trace: 0.35, forgotten: 0.1 };
const KIND_W = { promise: 1.0, firstMeet: 1.0, emotion: 0.75, owner: 0.6, event: 0.45 };

/** 「像在问旧事」的触发词：有它才值得为她去翻卡 */
const RECALL_CUES = /(记得|上次|之前|那次|当时|那天|那时候|说好|约好|答应|约定|说过|提过|忘了|想起来|还记得|我们聊过|跟你讲)/;

function envFlag(name, fallback) {
  const v = process.env[name];
  if (v === undefined || v === '') return fallback;
  const s = String(v).trim().toLowerCase();
  if (['0', 'false', 'off', 'no'].includes(s)) return false;
  if (['1', 'true', 'on', 'yes'].includes(s)) return true;
  return fallback;
}

function bigrams(text, dropStop = false) {
  let t = String(text || '');
  if (dropStop) for (const w of QUERY_STOP) t = t.split(w).join(' ');
  const out = [];
  const seen = new Set();
  for (const run of t.match(CJK_RUN) || []) {
    const grams = run.length > 1 ? Array.from({ length: run.length - 1 }, (_, i) => run.slice(i, i + 2)) : [run];
    for (const g of grams) if (!seen.has(g)) { seen.add(g); out.push(g); }
  }
  for (const w of t.match(LATIN_WORD) || []) {
    const lw = w.toLowerCase();
    if (!seen.has(lw)) { seen.add(lw); out.push(lw); }
  }
  return out;
}

function normalize(text) {
  return String(text || '').normalize('NFKC').replace(/\s+/g, '').toLowerCase();
}

function recordText(r) {
  const strip = (t) => String(t || '').replace(/^\s*(?:和主人|主人|渊（角色）|角色)\s*[:：]\s*/, '').trim();
  const title = strip(r?.title);
  const body = [strip(r?.text), String(r?.detail || '').trim()].filter(Boolean).join(' ');
  const reply = String(r?.botReply || '').trim();
  const head = title && body && normalize(title).slice(0, 12) === normalize(body).slice(0, 12) ? '' : title;
  return [head, body, reply ? `（当时回：${reply.slice(0, 120)}）` : ''].filter(Boolean).join(' ').trim();
}

function recency(ts) {
  const t = Date.parse(String(ts || ''));
  if (!Number.isFinite(t)) return 0.3;
  const days = Math.max(0, (Date.now() - t) / 86400000);
  return Math.exp(-days / 120);
}

/** 解析记忆卡，按 mtime+size 缓存；返回 { docs, df, n } */
const cardCache = { key: '', data: null };

function loadCard(cardPath) {
  let stat;
  try {
    stat = fs.statSync(cardPath);
  } catch {
    return null;
  }
  const key = `${stat.mtimeMs}:${stat.size}`;
  if (cardCache.key === key && cardCache.data) return cardCache.data;

  let parsed;
  try {
    parsed = JSON.parse(fs.readFileSync(cardPath, 'utf8').replace(/^\uFEFF/, ''));
  } catch {
    return null;
  }
  const records = Array.isArray(parsed?.records) ? parsed.records : [];
  const docs = [];
  const df = new Map();
  for (const r of records) {
    if (r?.sensitive) continue;
    const text = recordText(r);
    if (!text) continue;
    const grams = new Set(bigrams(normalize(text)).slice(0, 400));
    for (const g of grams) df.set(g, (df.get(g) || 0) + 1);
    docs.push({
      id: r?.id || '',
      text,
      grams,
      importance: Math.max(0, Math.min(1, Number(r?.importance || 0) / 100)),
      clarity: CLARITY_W[r?.clarity] ?? 0.6,
      kind: KIND_W[r?.kind] ?? 0.55,
      recency: recency(r?.createdAt),
      ts: String(r?.createdAt || ''),
    });
  }
  const data = { docs, df, n: docs.length, at: Date.now() };
  cardCache.key = key;
  cardCache.data = data;
  return data;
}

function jaccard(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter += 1;
  return inter / (a.size + b.size - inter);
}

/**
 * 生成注入块。返回 '' 表示这轮不注入（查询为空/无相关/命中太弱）。
 *
 * @param {object} opts
 * @param {string} opts.cardPath  memory-card.json 的绝对路径
 * @param {string} opts.query     主人这轮说的话
 * @param {number} [opts.top]     最多几条（默认 2）
 * @param {number} [opts.maxChars] 正文总字数（默认 420）
 */
export function buildMemoryRecallBlock({ cardPath, query, top = 2, maxChars = 420 } = {}) {
  if (!envFlag('SURFCORE_MEMORY_RECALL', true)) return '';
  const q = String(query || '').trim();
  if (!q || q.length > 500) return '';
  if (!cardPath) return '';

  const card = loadCard(cardPath);
  if (!card || !card.n) return '';

  const toks = bigrams(q, true).slice(0, 24);
  if (!toks.length) return '';

  const present = toks.filter((t) => (card.df.get(t) || 0) > 0);
  if (!present.length) return '';
  const weight = (t) => Math.log(1 + card.n / Math.max(1, card.df.get(t) || 0));
  const wsum = present.reduce((s, t) => s + weight(t), 0) || 1;

  const cues = RECALL_CUES.test(q);
  // 有"在问旧事"的迹象：命中一个词就够；没有：至少两个词，避免泛词单独翻旧事
  const needMatched = cues ? 1 : 2;
  // 证据门槛随库大小缩放（绝对 IDF 之和）：小卡不苛刻，大卡要求更硬的命中
  const minEvidence = Math.log(1 + Math.max(6, card.n) / 10);

  const scored = [];
  for (const d of card.docs) {
    const matched = present.filter((t) => d.grams.has(t));
    if (!matched.length) continue;
    if (matched.length < needMatched) continue;
    // 绝对证据：命中词的 IDF 之和要够（避免"今天"这种泛词单独成事）
    const evidence = matched.reduce((s, t) => s + weight(t), 0);
    if (evidence < minEvidence) continue;
    const cov = evidence / wsum; // 只用于排序/非问旧事场景的兜底门槛
    if (!cues && cov < 0.45) continue;
    const score = 0.5 * cov + 0.2 * d.importance + 0.1 * d.recency + 0.2 * (0.5 * d.kind + 0.5 * d.clarity);
    scored.push({ d, cov, score, evidence });
  }
  if (!scored.length) return '';
  scored.sort((a, b) => b.score - a.score);

  // 没有「在问旧事」的迹象时，要求很强的字面命中才注入，避免每轮都翻旧账
  if (!cues && scored[0].score < 0.66) return '';

  const picked = [];
  for (const item of scored) {
    if (picked.some((p) => jaccard(p.d.grams, item.d.grams) > 0.75)) continue;
    picked.push(item);
    if (picked.length >= top) break;
  }
  if (!picked.length) return '';

  const per = Math.max(80, Math.floor(maxChars / picked.length));
  const lines = ['【可能相关的旧事（你自己的记忆，按这句话想起来的）】'];
  for (const { d } of picked) {
    const body = d.text.replace(/\s+/g, ' ').trim();
    lines.push(`· ${body.length > per ? `${body.slice(0, per - 1)}…` : body}`);
  }
  lines.push('（只在真的对得上时自然提一句；对不上就当没看见，不要照读，也别提“记忆库”。）');
  if (envFlag('SURFCORE_MEMORY_RECALL_DEBUG', false)) {
    console.error(`[memory-recall] cue=${cues} n=${picked.length} q=${q.slice(0, 40)}`);
  }
  return lines.join('\n');
}

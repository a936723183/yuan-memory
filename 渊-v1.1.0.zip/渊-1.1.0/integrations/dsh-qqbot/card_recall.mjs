/**
 * card_recall.mjs — 角色查「自己的」长期记忆（只读）
 *
 * 为什么要它：她的记忆每轮靠桥接注入一张预渲染卡（≤2200 字），装不下的旧事就永远想不起来，
 * 也没有「想起来」这个动作。本工具给她补一个动作：需要回忆某件旧事时，自己去她的记忆卡里查。
 *
 * 边界（重要）：
 *   · 只读 characters/<角色>/memory/memory-card.json（经 E:\dsh-yuan\qqcard.py 建的独立索引）；
 *   · **不改**记忆卡、不改桥接注入、不动 memory.mode —— 不查时行为和以前一模一样；
 *   · 不读 ~/.dsh/memories（那是 DSH 侧的记忆，不是她的）；
 *   · 失败只报错、不静默：查不到就说查不到，别编。
 *
 * 生效方式：放进 {dataRoot}/.qqbot-extensions/tools/ 后，在 QQ 发 /tools-reload；无需重启。
 * 回滚：删掉本文件 + /tools-reload。
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const SCRIPT = process.env.QQ_CARD_SCRIPT || 'E:\\dsh-yuan\\qqcard.py';
const PYTHON_CANDIDATES = [
  process.env.QQ_CARD_PYTHON,
  'E:\\6deepseek\\python\\python.exe',
  'python',
].filter(Boolean);

function pickPython() {
  for (const p of PYTHON_CANDIDATES) {
    if (p === 'python') return p;
    try { if (fs.existsSync(p)) return p; } catch { /* ignore */ }
  }
  return 'python';
}

/** 跑 qqcard.py，返回 { code, stdout, stderr } */
function runPython(args, timeoutMs = 12000) {
  return new Promise((resolve) => {
    const py = pickPython();
    let out = '', err = '', done = false;
    let child;
    const finish = (r) => { if (!done) { done = true; resolve(r); } };
    try {
      child = spawn(py, [SCRIPT, ...args], {
        cwd: path.dirname(SCRIPT),
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe'],
        env: { ...process.env, PYTHONIOENCODING: 'utf-8' },
      });
    } catch (e) {
      return finish({ code: -1, stdout: '', stderr: String(e?.message || e) });
    }
    const timer = setTimeout(() => { try { child.kill(); } catch { /* ignore */ } finish({ code: -2, stdout: out, stderr: '查询超时' }); }, timeoutMs);
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    child.on('error', (e) => { clearTimeout(timer); finish({ code: -1, stdout: out, stderr: String(e?.message || e) }); });
    child.on('close', (code) => { clearTimeout(timer); finish({ code: code ?? -1, stdout: out, stderr: err }); });
  });
}

function fmt(res) {
  const lines = [`我自己的记忆（查「${res.query}」）：`];
  for (const it of res.items) {
    const when = String(it.ts || '').slice(0, 10);
    const mark = it.confidence === 'low' ? '（模糊）' : '';
    lines.push(`${it.rank}. ${mark}${it.text}${when ? `（${when}）` : ''}`);
  }
  if (res.fuzzy) lines.push('以上只是相关话题，不是精确命中；说的时候别当成确定的事。');
  return lines.join('\n');
}

export default {
  name: 'card_recall',
  description:
    '查「我自己」的长期记忆（只读）：过去说过的话、约定、分享过的事。'
    + '当需要回忆某件旧事、或不确定之前答应过什么时先调用它，再回答；'
    + '查不到就如实说没记到，不要编。不影响每轮自动注入的记忆卡。',
  expose: 'all',
  inputSchema: {
    query: { type: 'string', description: '要回忆的事，用自然语言一句话，例如「评论到底发没发」「我答应过她什么」' },
    top: { type: 'integer', description: '最多返回几条（默认 4，上限 8）' },
    chars: { type: 'integer', description: '正文总字数预算（默认 500，上限 1200）' },
  },

  async run(args = {}) {
    const query = String(args?.query ?? '').trim();
    if (!query) return { ok: false, msg: '需要 query：要回忆什么？' };
    if (query.length > 200) return { ok: false, msg: 'query 太长（≤200 字）' };

    if (!fs.existsSync(SCRIPT)) {
      return { ok: false, msg: `找不到检索脚本：${SCRIPT}（工具装好了但脚本不在，检查 E:\\dsh-yuan\\qqcard.py）` };
    }

    const top = Math.max(1, Math.min(8, Number(args?.top) > 0 ? Math.floor(Number(args.top)) : 4));
    const chars = Math.max(120, Math.min(1200, Number(args?.chars) > 0 ? Math.floor(Number(args.chars)) : 500));

    const r = await runPython(['recall', query, '--top', String(top), '--chars', String(chars), '--json']);

    if (r.code !== 0) {
      const why = (r.stderr || '').trim().slice(0, 200);
      return { ok: false, msg: `记忆检索失败（${r.code === -2 ? '超时' : `退出码 ${r.code}`}）：${why || '无输出'}` };
    }

    let res;
    try { res = JSON.parse((r.stdout || '').trim().split('\n').filter(Boolean).pop() || '{}'); }
    catch { return { ok: false, msg: `检索结果不是合法 JSON：${(r.stdout || '').slice(0, 160)}` }; }

    if (!res.ok) return { ok: false, msg: `检索失败：${res.error || '未知原因'}` };
    if (!res.count) return { ok: true, msg: `我自己的记忆里没查到和「${query}」相关的记录（库里共 ${res.total} 条）。没记到就是没记到，别编。` };

    return { ok: true, msg: `${fmt(res)}\n（共 ${res.total} 条记忆，本次命中 ${res.count} 条）` };
  },
};

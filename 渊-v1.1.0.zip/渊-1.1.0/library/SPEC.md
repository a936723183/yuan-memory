# 记忆图书馆 v2 · 可执行规格（草案 v0.9）

> 目标：把现有「渊」升级为双区域、分层、可重建的记忆库。
> 本文只定义**能直接照着写代码**的部分：表、接口、状态机、打分、迁移、测试。
> 未列出的实现细节自行决定，但**不变量**不可破。

---

## 0. 不变量（任何改动都不能破）

1. **md/jsonl 是唯一真相源**；SQLite 是缓存，`rebuild` 能从真相源完整还原。
2. **真相源只追加，永不原地改写**（compact 是离线生成新世代，见 §6）。
3. **库写失败不影响成功**：md 落盘成功即视为写入成功；库失败标 `pending_index` 由后台补。
4. **同一时刻只有一个检索源**：迁移期不并行双源检索（见 §7）。
5. **不读、不回显密钥**：密钥/盐只从 OS 凭据管理器取，任何日志、摘要、报告都不含密钥。
6. **`seq_alloc` 的序号更新必须与记忆写入处在同一个 SQLite 事务内**。若二者分属不同事务，进程被 kill 后会重复分配相同 id，jsonl 出现多条同 id 记录（2026-11-11 kill 测试实测复现）。

---

## 1. 目录布局

```
<memory_root>/
  manifest.json                 # 指针：当前世代、各区域文件清单、sha256
  dsh_zone/
    20261111.jsonl              # 真相源（append-only，一行一条 JSON）
    20261111.jsonl.<gen>.bak    # compact 后保留的旧世代（只读）
  qq_zone/
    ...
  reports/
    import_report-<ts>.json
    check_report-<ts>.json
    bench-<ts>.json
```

`source_path` 一律相对 `<memory_root>`，**不含盘符**；迁移只改配置里的 `memory_root`。

---

## 2. DDL

```sql
-- 2.1 主表：轻，只放可检索字段与指针
CREATE TABLE memory (
  id               TEXT PRIMARY KEY,              -- dsh-20261111-000123
  region           TEXT NOT NULL CHECK(region IN ('dsh_zone','qq_zone')),
  content_abstract TEXT NOT NULL,                 -- 摘要（敏感条目为密文）
  source_path      TEXT NOT NULL,                 -- 相对路径
  src_offset       INTEGER NOT NULL,              -- 写入时 tell()
  src_len          INTEGER NOT NULL,
  content_sha256   TEXT NOT NULL,                 -- 非敏感=sha256；敏感=HMAC(dedup_salt)
  is_sensitive     INTEGER NOT NULL DEFAULT 0,
  keyword_list     TEXT,
  alias_list       TEXT,
  mem_type         TEXT NOT NULL DEFAULT 'normal'
                     CHECK(mem_type IN ('config','preference','draft','normal')),
  create_time_utc  TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'normal'
                     CHECK(status IN ('normal','deprecated')),
  storage_type     TEXT NOT NULL DEFAULT 'normal'
                     CHECK(storage_type IN ('normal','archive')),   -- 仅影响排序权重
  embedding_id     TEXT,
  vec_status       TEXT NOT NULL DEFAULT 'uncalculated'
                     CHECK(vec_status IN ('uncalculated','ready','failed','dead','skipped_sensitive')),
  UNIQUE(region, content_sha256)
);
CREATE INDEX ix_mem_region_status ON memory(region, status);
CREATE INDEX ix_mem_region_storage ON memory(region, storage_type);

-- 2.2 运行期热度（检索缓存；真相在 heat_event_log）
CREATE TABLE memory_stats (
  memory_id       TEXT PRIMARY KEY,
  hot_score       REAL NOT NULL,
  hits            INTEGER NOT NULL DEFAULT 0,
  last_access_utc TEXT,
  updated_utc     TEXT NOT NULL
);

-- 2.3 热度事件（真相）：逐条明细
CREATE TABLE heat_event_log (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  memory_id TEXT NOT NULL,
  delta     REAL NOT NULL,
  event_utc TEXT NOT NULL,
  compacted INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX ix_heat_mem ON heat_event_log(memory_id, event_utc);

-- 2.4 热度事件聚合（明细超过 30 天后压缩成按天一行）
CREATE TABLE heat_event_rollup (
  memory_id TEXT NOT NULL,
  day       TEXT NOT NULL,          -- YYYY-MM-DD (UTC)
  net_delta REAL NOT NULL,          -- 当日净变化
  cnt       INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY(memory_id, day)
);

-- 2.5 向量
CREATE TABLE embedding_store (
  memory_id   TEXT PRIMARY KEY,
  embedding   BLOB,                 -- float32[]；敏感条目为 NULL 且 vec_status=skipped_sensitive
  dim         INTEGER,
  model_name  TEXT,
  model_version TEXT,
  vec_calc_status TEXT NOT NULL DEFAULT 'uncalculated'
                    CHECK(vec_calc_status IN ('uncalculated','ready','failed','dead')),
  updated_utc TEXT NOT NULL
);

-- 2.6 关联
CREATE TABLE relation (
  id            TEXT PRIMARY KEY,
  region        TEXT NOT NULL,
  node_a_id     TEXT NOT NULL,
  node_b_id     TEXT NOT NULL,
  relation_type TEXT NOT NULL
                  CHECK(relation_type IN ('依赖配置','配套素材','版本继承','反向参考','单纯提及')),
  confidence    REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
  source        TEXT NOT NULL CHECK(source IN ('manual','rule','model')),
  created_utc   TEXT NOT NULL,
  UNIQUE(region, node_a_id, node_b_id, relation_type)
);
CREATE INDEX ix_rel_a ON relation(node_a_id);
CREATE INDEX ix_rel_b ON relation(node_b_id);

-- 2.7 同义词
CREATE TABLE synonym (
  origin_text TEXT NOT NULL,
  alias_text  TEXT NOT NULL,
  PRIMARY KEY(origin_text, alias_text)
);

-- 2.8 写入日志（每次尝试一条，含失败）
CREATE TABLE write_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ts_utc      TEXT NOT NULL,
  region      TEXT NOT NULL,
  action      TEXT NOT NULL,        -- update/get/search/rebuild/retry/compact/import
  memory_id   TEXT,
  content_len INTEGER,
  result      TEXT NOT NULL CHECK(result IN ('ok','deduped','rejected','error')),
  error_code  TEXT,
  ms          INTEGER
);

-- 2.9 写入队列（落库，进程崩溃不丢）
CREATE TABLE write_queue (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  ts_utc       TEXT NOT NULL,
  region       TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  state        TEXT NOT NULL DEFAULT 'pending'
                 CHECK(state IN ('pending','doing','done','failed')),
  attempts     INTEGER NOT NULL DEFAULT 0,
  last_error   TEXT
);

-- 2.10 死信
CREATE TABLE dead_letter (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  memory_id TEXT NOT NULL,
  kind      TEXT NOT NULL CHECK(kind IN ('vector','index','md')),
  reason    TEXT,
  payload   TEXT,
  ts_utc    TEXT NOT NULL,
  resolved  INTEGER NOT NULL DEFAULT 0
);

-- 2.11 id 序号分配（仅单机）
CREATE TABLE seq_alloc (
  region TEXT NOT NULL,
  day    TEXT NOT NULL,
  seq    INTEGER NOT NULL,
  PRIMARY KEY(region, day)
);
```

---

## 3. 接口签名

所有接口统一返回 `{ok, data?, error?}`；`error` 为 `{code, message, retry_after_ms?}`。

| 接口 | 入参 | 出参 | 说明 |
|---|---|---|---|
| `memory_update` | `region, content, mem_type?, is_sensitive?, keyword_list?` | `{id, deduped, vec_status, stored_in_db}` | 同步写 md→写库→入队算向量；重复内容返回已有 id（`deduped=true`） |
| `memory_search` | `region, query, mode=task\|creative, top_k≤10, include_sensitive=false` | `[{id, abstract, score, track}]` | 默认任务模式；敏感条目只返回占位 |
| `memory_get` | `region, id, reveal=false` | `{abstract, content?, sensitive_locked}` | `reveal=true` 且非敏感才读原文 |
| `memory_rebuild` | `region` | `{scanned, rebuilt, skipped, mismatched}` | 冻结写入后全量重建 |
| `retry_vec` | `region, ids?\|all` | `{retried, ok, failed}` | 单条或批量重试向量 |
| `compact` | `region, before_date` | `{new_gen, files, bytes}` | **离线**；产出新世代 + manifest 原子切换 |
| `import_old_yuan` | `from_dir, region, dry_run?` | `{total, imported, dup, hash_mismatch, report_path}` | 见 §7 |
| `stats_export` | `region` | `{path}` | 导出 stats 快照 + 事件明细 |
| `check` | `region` | `{md_count, db_count, mismatch[], orphan[]}` | 对账；md 缺失/哈希不一致都报 |

### 错误码

| 码 | 含义 | 上层动作 |
|---|---|---|
| `E_INVALID` | 缺必填 / 枚举错 | 修参数，别重试 |
| `E_BUSY` | 队列满 | 退避重试（`retry_after_ms`） |
| `E_REBUILDING` | 重建锁 | **禁止重试**，等 ETA |
| `E_QUOTA` | 单日写入超限 | 禁止重试，提示人工 |
| `E_SENSITIVE_LOCKED` | 敏感条目未授权 | 提示需授权 |
| `E_DEDUP_CONFLICT` | 幂等键冲突但内容不同（哈希碰撞/同哈希不同文） | 人工确认 |

---

## 4. 状态机

**4.1 写入**

```
RECEIVED ──校验──失败──> REJECTED(E_INVALID)
   │
   ├─ append jsonl (fsync 成功) ──> MD_OK
   │        └─ 失败 ──> REJECTED(E_MD_WRITE)
   └─> 写 memory + memory_stats + write_log
            └─ 失败 ──> pending_index（后台补；不影响成功）
   └─> 入 write_queue ──> VECTOR_PENDING
```

**4.2 向量**

```
uncalculated ──算成功──> ready
     │              └─失败(1..3)──> failed ──重试──> uncalculated
     └─敏感条目──> skipped_sensitive
failed 重试超 3 次 ──> dead ──7 天后告警──> dead_letter（人工处理）
```

**4.3 重建锁**

```
IDLE ──rebuild 开始──> FROZEN(拒写: E_REBUILDING)
   ──扫描+重建──> SCANNING ──校验──> SWAPPING(manifest 原子换) ──> IDLE
任意阶段异常 ──> ROLLBACK ──> IDLE（保留旧库不变）
```

**4.4 迁移**

```
LEGACY ──冻结写入──> FROZEN ──全量导入──> IMPORTING ──对账+bench──> VERIFIED
   ──切 recall 入口──> SWITCHED ──双写 24h──> DUAL_WRITE ──停旧写──> DONE
异常 ──> 回滚：旧 md 只读保留，新库新增条目反向导出
```

---

## 5. 检索与打分

```
sim    = 有向量 → cosine(q, e)；无向量 → FTS 归一化分（bigram + IDF 覆盖率）
heat   = min(1, hot_score)
fresh  = exp(-days/120)                     # days 距 create_time
rel    = 邻接 1 跳最高置信度 × 0.5          # 仅创意模式

task:      score = 0.7*sim + 0.2*heat + 0.1*fresh
creative:  score = 0.4*sim + 0.2*heat + 0.1*fresh + 0.3*rel
```

硬约束：
- `status='normal'` 才入候选；`deprecated` 仅在回溯指令下参与
- `storage_type='archive'` **只降权 ×0.7，不禁止读取**
- `sim < 0.4` 丢弃；合并排序后 `top ≤ 10`
- 创意模式 1 跳且 `confidence ≥ 0.5`；`单纯提及` 边不参与拓展
- 敏感条目：不过 FTS 正文、不算向量；只有 `include_sensitive=true` 才返回，且只给占位

---

## 6. 冷热与衰减

```
tasks:
  config      half_life = 365 天
  preference  half_life = 180 天
  normal      half_life = 60 天
  draft       half_life = 14 天

hot_score(t) = base * 0.5^(days/half_life) + 0.3*min(1, hits/5)
state: heat≥0.6 且 45 天内命中 → hot；heat<0.15 → cold(archive)；否则 warm
```

`archive` 判定后只改 `storage_type`，**不动 source_path、不删原文**。

---

## 7. 迁移（三阶段，禁止实时双源）

| 阶段 | 动作 | 验收 |
|---|---|---|
| 1 导入 | 冻结写入 → 扫描旧 md → 逐条算 sha256 → 写新 jsonl（拿 offset）→ 写库 → 迁移 hot_score/hits 为热事件基线 | 条数相等；`import_report` 零 hash 不一致 |
| 2 切换 | `recall` 入口指向新库；旧 md 转只读备份；跑旧 bench | 20 题命中率不低于旧库（100%@6） |
| 3 收尾 | 双写 24h 覆盖回滚窗口 → 停旧写 → 旧库归档 | 双写期无重复条目（dedup 两边同判） |

**回滚**：保留旧 md 只读 + 切换前 24h 双写，回滚时反向导出新库增量。

---

## 8. 测试用例（12 条）

| # | 用例 | 期望 |
|---|---|---|
| T1 | 同区写入一条 normal，立即 search | 能检索到，`vec_status=uncalculated` |
| T2 | 同一内容写两次 | 第二次 `deduped=true`，库内仍 1 条 |
| T3 | 写一条与已有相似度 >0.85 的新记忆 | 旧的 `deprecated`，新的可检索，旧的仍可 `get` |
| T4 | 写 25KB 长文 | 主表无 `content_full`，`src_len` 正确，`get(reveal)` 能取全文 |
| T5 | `archive` 一条后常规 search | 搜不到；`get` 与回溯指令能取 |
| T6 | 任务模式检索 | 结果中无 1 跳邻居 |
| T7 | 创意模式检索 | 出现 1 跳邻居且仅 1 跳，`confidence<0.5` 的边被过滤 |
| T8 | 敏感条目写入 | 不算向量、FTS 无正文、search 只返回占位、`get(reveal)` 报 `E_SENSITIVE_LOCKED` |
| T9 | 删除 `yuan.db` 后 `memory_rebuild` | 条数与热度和重建前一致（允许 ± 明细缺失） |
| T10 | 写入时人工 kill 进程 | 重启后 `write_queue` 有 pending，不丢；jsonl 无半行 |
| T11 | 跨区：`dsh_zone` 尝试写 `qq_zone` | 拒绝；QQ 库文件哈希前后一致 |
| T12 | `import_old_yuan --dry-run` | 报告条数、重复数、哈希不一致清单，不写任何数据 |

---

## 9. 运维

- **备份**：jsonl + manifest + `stats_export` 快照；**密钥/盐分开存**（凭据管理器，不进备份包）
- **对账**：每日 `check`；md 缺条、哈希不符、孤儿向量都要告警
- **轮换**：加密密钥可轮换（重加密）；**dedup salt 不应轮换**（轮换需 `rehash_dedup` 全量重算）
- **告警**：向量 `dead` 超 7 天、队列积压超 1k、manifest 校验失败
- **compact**：离线、带 gen 号、manifest 原子切换、旧世代保留 ≥7 天

---

## 10. 已知取舍（写进文档，别当 bug）

1. 默认「关键词优先 + 向量精排」，纯语义无关键词召回需显式开关
2. 敏感条目不可被联想检索（只精确查找）
3. 单机 id 方案（`region-yyyymmdd-seq6`），多机需改 ULID
4. 不做压缩归档；冷归档只是状态标记
5. 事件明细保留 30 天，更早靠日汇总重放（只能还原总量，不能还原时序）

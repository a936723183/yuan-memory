#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
vec.py · A 档向量检索（HTTP 客户端 + 熔断 + 信号量 + LRU + 两步归一融合）
=========================================================================
约束：
  - 150ms 总超时；拿不到信号量直接降级（VecBusy，不计熔断）
  - 传输错误（超时/连接/5xx）才计 streak；401/403 与维度错误只记错
  - 连续 3 次 → 5 分钟熔断，状态存 kv；探活失败 → 60s 短屏蔽，不叠加 streak
  - 探活失败不是永久的：probe_retry_at 到点允许重试
  - 两步独立 min-max：fts 在全部候选上；cos 只在 ready 子集上
  - ready 0 条 → 全 fts-only；1 条 → cos_norm=0.5；≥2 条 → min-max，全等给 0.5
  - 向量查询用 IN 子句，禁止全表扫
"""
from __future__ import annotations

import array
import json
import math
import os
import threading
import time
import urllib.error
import urllib.request

ENDPOINT = (os.environ.get("MEM_EMBEDDING_ENDPOINT") or "https://api.siliconflow.cn").rstrip("/")
TOKEN = (os.environ.get("MEM_EMBEDDING_TOKEN") or os.environ.get("SILICONFLOW_API_KEY") or "")
MODEL = os.environ.get("MEM_EMBEDDING_MODEL") or "BAAI/bge-m3"
SPACE = os.environ.get("MEM_EMBEDDING_SPACE") or "bge-m3@1024-cloud-siliconflow"
DIM = int(os.environ.get("MEM_EMBEDDING_DIM") or "1024")
_enabled_env = os.environ.get("VECTORS_ENABLED")
ENABLED = (str(_enabled_env).lower() in ("1", "true", "yes")) if _enabled_env is not None else bool(TOKEN)
# off=完全不用；on=一直用；ondemand=按 vec on 临时开启（默认）
MODE = (os.environ.get("MEM_VECTORS_MODE") or "ondemand").lower()
TIMEOUT = float(os.environ.get("MEM_EMBEDDING_TIMEOUT_MS", "800")) / 1000.0
W_COS = float(os.environ.get("MEM_VEC_W_COS", "0.6"))
FALLBACK = float(os.environ.get("MEM_VEC_FALLBACK", "0.5"))
BREAKER_THRESHOLD = 3
BREAKER_SECONDS = 300
PROBE_BACKOFF = 60
# 业务查询限流（回填/后台任务不受限）
RATE_PER_MIN = int(os.environ.get("MEM_VEC_RATE_PER_MIN", "30"))
_rate = {"minute": "", "count": 0}

_sem = threading.Semaphore(2)
_cache: dict[str, tuple[list[float], float]] = {}
_cache_lock = threading.Lock()
_probe_lock = threading.Lock()


class VecAuth(Exception):
    pass


class VecDown(Exception):
    pass


class VecBusy(Exception):
    """本地并发拒绝：只降级，不计熔断。"""


class VecBad(Exception):
    pass


# ---------------------------------------------------------------- kv

def _kv_get(db, k, d=None):
    row = db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
    return row["v"] if row else d


def _kv_set(db, k, v):
    db.execute("INSERT OR REPLACE INTO kv(k,v) VALUES(?,?)", (k, str(v)))


def breaker_open(db) -> bool:
    try:
        return time.time() < float(_kv_get(db, "vec_breaker_until", "0") or 0)
    except Exception:
        return False


def _on_transport_fail(db):
    try:
        streak = int(_kv_get(db, "vec_fail_streak", "0") or 0) + 1
        _kv_set(db, "vec_fail_streak", streak)
        if streak >= BREAKER_THRESHOLD:
            _kv_set(db, "vec_breaker_until", str(time.time() + BREAKER_SECONDS))
            _kv_set(db, "vec_fail_streak", 0)
            _kv_set(db, "vec_breaker_hits", int(_kv_get(db, "vec_breaker_hits", "0") or 0) + 1)
        db.commit()
    except Exception:
        pass


def _on_success(db):
    try:
        if int(_kv_get(db, "vec_fail_streak", "0") or 0) != 0:
            _kv_set(db, "vec_fail_streak", 0)
            db.commit()
    except Exception:
        pass


# ---------------------------------------------------------------- HTTP

def _post(txts: list[str]) -> list[list[float]]:
    if not ENDPOINT:
        raise VecDown("未配置 endpoint")
    body = json.dumps({"model": MODEL, "input": txts}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        ENDPOINT + "/v1/embeddings", data=body, method="POST",
        headers={"Content-Type": "application/json",
                 **({"Authorization": "Bearer " + TOKEN} if TOKEN else {})})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise VecAuth(f"鉴权失败 HTTP {e.code}")
        if e.code >= 500:
            raise VecDown(f"服务端错误 HTTP {e.code}")
        raise VecBad(f"请求错误 HTTP {e.code}")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise VecDown(f"连接/超时: {type(e).__name__}")

    data = payload.get("data")
    if not isinstance(data, list) or len(data) != len(txts):
        raise VecBad("返回条目数不匹配")
    out = []
    for item in data:
        v = item.get("embedding")
        if not isinstance(v, list) or len(v) != DIM:
            raise VecBad(f"维度不符：期望 {DIM}，得到 {len(v) if isinstance(v, list) else 'N/A'}")
        out.append([float(x) for x in v])
    return out


def _probe_ok() -> bool:
    """本地服务有 /health；云端（如 SiliconFlow）只有 /v1/models，逐个试。"""
    headers = {"Authorization": "Bearer " + TOKEN} if TOKEN else {}
    for suffix in ("/health", "/v1/models"):
        req = urllib.request.Request(ENDPOINT + suffix, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                if 200 <= resp.status < 300:
                    return True
        except urllib.error.HTTPError as e:
            if e.code == 404:      # 该端点不存在，换下一个
                continue
            if e.code in (401, 403):   # 端点存在但 key 不对：不可用
                return False
            return False
        except Exception:
            return False
    return False


def health(db) -> bool:
    if not ENDPOINT:
        return False
    ok = _probe_ok()
    try:
        if ok:
            _kv_set(db, "vec_breaker_until", "0")
            _kv_set(db, "vec_fail_streak", "0")
            _kv_set(db, "vec_probe_ok", "1")
            _kv_set(db, "vec_probe_retry_at", "0")
        else:
            _kv_set(db, "vec_probe_ok", "0")
            _kv_set(db, "vec_breaker_until", str(time.time() + PROBE_BACKOFF))
            _kv_set(db, "vec_probe_retry_at", str(time.time() + PROBE_BACKOFF))
        db.commit()
    except Exception:
        pass
    return ok


def ondemand_until(db) -> float:
    try:
        return float(_kv_get(db, "vec_ondemand_until", "0") or 0)
    except Exception:
        return 0.0


def available(db) -> bool:
    """关闭 / 按需未开启 / 熔断 / 探活失败 → False。"""
    if not ENABLED:
        return False
    if MODE == "off":
        return False
    if MODE == "ondemand" and time.time() >= ondemand_until(db):
        return False
    if breaker_open(db):
        return False
    try:
        ok = _kv_get(db, "vec_probe_ok")
        retry_at = float(_kv_get(db, "vec_probe_retry_at", "0") or 0)
    except Exception:
        ok, retry_at = None, 0
    if ok == "1":
        return True
    if time.time() < retry_at:
        return False
    with _probe_lock:
        return health(db)


# ---------------------------------------------------------------- 编码

def _rate_ok() -> bool:
    m = time.strftime("%Y%m%d%H%M")
    if _rate["minute"] != m:
        _rate["minute"], _rate["count"] = m, 0
    if _rate["count"] >= RATE_PER_MIN:
        return False
    _rate["count"] += 1
    return True


def embed(texts: list[str], db, use_cache: bool = True, use_sem: bool = True) -> list[list[float]]:
    results: list[list[float] | None] = [None] * len(texts)
    now = time.time()
    pending: list[tuple[int, str]] = []
    for i, t in enumerate(texts):
        if use_cache:
            with _cache_lock:
                hit = _cache.get(t)
                if hit and now - hit[1] < 300:
                    results[i] = hit[0]
                    continue
        pending.append((i, t))
    if not pending:
        return [r for r in results if r is not None]  # type: ignore

    acquired = False
    if use_sem:
        if not _rate_ok():
            raise VecBusy(f"限流：{RATE_PER_MIN}/分钟")
        if not _sem.acquire(blocking=False):
            raise VecBusy("并发已满")
        acquired = True
    try:
        try:
            vecs = _post([t for _, t in pending])
            _on_success(db)
        except VecDown:
            _on_transport_fail(db)
            raise
    finally:
        if acquired:
            _sem.release()

    for (i, t), v in zip(pending, vecs):
        results[i] = v
        with _cache_lock:
            if len(_cache) >= 32:
                oldest = min(_cache.items(), key=lambda kv: kv[1][1])[0]
                _cache.pop(oldest, None)
            _cache[t] = (v, now)
    return [r for r in results if r is not None]  # type: ignore


# ---------------------------------------------------------------- 数学

def cosine(a: list[float], b: list[float]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def minmax(values: dict[str, float]) -> dict[str, float]:
    """全等（差值 <1e-9）返回中性 0.5，避免向量项被拉满。"""
    if not values:
        return {}
    if len(values) == 1:
        return {k: 0.5 for k in values}
    lo, hi = min(values.values()), max(values.values())
    if hi - lo < 1e-9:
        return {k: 0.5 for k in values}
    return {k: (v - lo) / (hi - lo) for k, v in values.items()}


def _load_vectors(db, ids: list[str]) -> dict[str, list[float]]:
    if not ids:  # 空列表短路：禁止生成 IN ()
        return {}
    marks = ",".join("?" * len(ids))
    # 必须同时满足：store 行 ready + memory.vec_status=ready（否则状态错配时仍会被当作有向量）
    rows = db.execute(
        f"SELECT e.memory_id,e.embedding,e.model_name,e.model_version FROM embedding_store e "
        f"JOIN memory m ON m.id=e.memory_id "
        f"WHERE e.vec_calc_status='ready' AND m.vec_status='ready' AND e.memory_id IN ({marks})",
        ids).fetchall()
    out: dict[str, list[float]] = {}
    for r in rows:
        if r["model_name"] != MODEL or r["model_version"] != SPACE:
            continue
        try:
            blob = r["embedding"]
            if isinstance(blob, str):
                out[r["memory_id"]] = json.loads(blob)
            else:
                arr = array.array("f")
                arr.frombytes(blob)
                out[r["memory_id"]] = list(arr)
        except Exception:
            continue
    return out


def fuse(db, region: str, query: str, items: list[tuple[str, float]]) -> dict[str, tuple[float, str]]:
    """items: [(memory_id, fts_score 越高越好)] → {id: (sim, source)}"""
    if not items:
        return {}
    fts_norm = minmax({mid: s for mid, s in items})
    fts_only = {mid: (f, "fts-only") for mid, f in fts_norm.items()}

    if not available(db):
        return fts_only

    ready = _load_vectors(db, [mid for mid, _ in items])
    if not ready:
        return fts_only
    if len(ready) == 1:
        mid = next(iter(ready))
        out = dict(fts_only)
        out[mid] = (W_COS * 0.5 + (1 - W_COS) * fts_norm[mid], "mixed")
        return out

    try:
        qv = embed([query], db)[0]
    except Exception:
        return fts_only

    cos_raw = {mid: cosine(qv, v) for mid, v in ready.items() if mid in fts_norm}
    if len(cos_raw) < 2:
        return fts_only
    cos_norm = minmax(cos_raw)

    out = dict(fts_only)
    for mid, c in cos_norm.items():
        out[mid] = (W_COS * c + (1 - W_COS) * fts_norm[mid], "mixed")
    return out


def pack(vec: list[float]) -> bytes:
    return array.array("f", vec).tobytes()


def upsert_vector(db, memory_id: str, vec: list[float]):
    db.execute(
        "INSERT OR REPLACE INTO embedding_store(memory_id,embedding,dim,model_name,model_version,"
        "vec_calc_status,updated_utc) VALUES(?,?,?,?,?,'ready',?)",
        (memory_id, pack(vec), len(vec), MODEL, SPACE,
         time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())))
    db.execute("UPDATE memory SET vec_status='ready', embedding_id=? WHERE id=?", (memory_id, memory_id))

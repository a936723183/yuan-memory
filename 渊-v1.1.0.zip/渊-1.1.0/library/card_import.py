# -*- coding: utf-8 -*-
"""记忆卡 → 记忆图书馆（qq_zone）单向导入。

定位（按 2026-11-13 的分层方案）：
    · **记忆卡是唯一真相**：本脚本只读 memory-card.json，一个字都不写回去；
    · 图书馆只是派生副本：把卡的每条记录作为一条记忆存进 `qq_zone`，
      敏感条目标 is_sensitive（由 memlib 用 Fernet 加密正文）；
    · 幂等：memlib 自带 content_sha256 去重，同一文本重复导入不会重复入库；
    · 可重建：删掉 qq_zone 里的行，重跑本脚本即可恢复。

用法：
    python card_import.py --dry-run          # 只看会写多少条
    python card_import.py                    # 真写
    python card_import.py --since-days 30    # 只导最近 30 天新建的
"""
import argparse
import glob
import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

MEM_ROOT = Path(os.environ.get("MEM_ROOT") or str(Path(__file__).resolve().parent.parent / "data" / "library"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

DSH_HOME = Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))
CARD_GLOB = str(DSH_HOME / "surfcore" / "characters" / "*" / "memory" / "memory-card.json")
STATE = MEM_ROOT / "card_import_state.json"

PREFIX = ("和主人", "主人", "渊（角色）", "角色", "渊")


def pick_card(explicit: str = "") -> Path:
    if explicit:
        return Path(explicit)
    paths = sorted(Path(p) for p in glob.glob(CARD_GLOB))
    if not paths:
        sample = Path(__file__).resolve().parent.parent / 'samples' / 'memory-card.sample.json'
        if sample.exists():
            return sample
        raise SystemExit(f"没有找到记忆卡：{CARD_GLOB}")
    return max(paths, key=lambda p: p.stat().st_mtime)


SPEAKER_RE = __import__("re").compile(r"^\s*(?:[^：:\s]{0,4}(?:主人|角色|渊|角色|她)[^：:\s]{0,6}|渊（[^）]{1,8}）)\s*[：:]\s*")


def clean(t) -> str:
    s = str(t or "").strip()
    m = SPEAKER_RE.match(s)
    if m and (("：" in s[:14]) or (":" in s[:14])):
        s = s[m.end():].strip()
    return s


def record_text(r: dict) -> str:
    title = clean(r.get("title"))
    body = clean(r.get("text"))
    detail = str(r.get("detail") or "").strip()
    reply = str(r.get("botReply") or "").strip()
    parts = []
    # 标题是正文截断版就不重复（按去空白后的前 20 字比）
    import re as _re
    compact = lambda s: _re.sub(r"\s+", "", s)
    if title and not (body and compact(body).startswith(compact(title)[:20])):
        parts.append(title)
    if body:
        parts.append(body)
    if detail:
        parts.append(detail)
    if reply:
        parts.append("（她当时回：%s）" % reply[:200])
    return " ".join(p for p in parts if p).strip()


def mem_type(r: dict) -> str:
    kind = str(r.get("kind") or "")
    imp = float(r.get("importance") or 0)
    if r.get("pinned") or r.get("anchor") or kind in ("firstMeet", "promise") or imp >= 70:
        return "config"
    if kind == "owner" and imp >= 60:
        return "preference"
    return "normal"


def _lock_guard():
    """名字写死为「渊」：清单或目录被改名 → 自锁 + 焚毁索引（记忆源不动）。"""
    if any(a in ("unlock", "doctor") for a in sys.argv[1:]):
        return
    try:
        from name_lock import enforce_name
    except Exception:
        return
    enforce_name(Path(__file__).resolve().parent.parent)


def main() -> int:
    _lock_guard()
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="记忆卡 → 图书馆 qq_zone（只读卡）")
    ap.add_argument("--card", default="")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--since-days", type=int, default=0, help="只导最近 N 天创建的记录（0=全部）")
    args = ap.parse_args()

    path = pick_card(args.card)
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    records = data.get("records") or []
    cutoff = None
    if args.since_days > 0:
        cutoff = datetime.now().astimezone() - timedelta(days=args.since_days)

    picked, skipped_sensitive_text, too_short = [], 0, 0
    for r in records:
        text = record_text(r)
        if not text:
            continue
        if cutoff:
            try:
                ts = datetime.fromisoformat(str(r.get("createdAt") or "").replace("Z", "+00:00"))
                if ts < cutoff:
                    continue
            except ValueError:
                pass
        if len(text) < 4:
            too_short += 1
            continue
        picked.append((r, text))

    print(f"卡：{path}")
    print(f"记录 {len(records)} 条 → 待导入 {len(picked)} 条"
          f"（敏感 {sum(1 for r, _ in picked if r.get('sensitive'))} 条按加密标记写入）")
    if args.dry_run:
        for r, text in picked[:5]:
            print(f"  · [{mem_type(r)}] {text[:80]}")
        print("（dry-run，未写入）")
        return 0

    import memlib  # noqa: E402

    added = deduped = failed = 0
    mapping = {}
    for r, text in picked:
        try:
            res = memlib.memory_update(
                "qq_zone", text,
                mem_type=mem_type(r),
                is_sensitive=bool(r.get("sensitive")),
            )
            mapping[str(r.get("id") or "")] = res.get("id", "")
            if res.get("deduped"):
                deduped += 1
            else:
                added += 1
        except Exception as exc:
            failed += 1
            print(f"  失败：{str(r.get('id'))[:12]} → {exc}", file=sys.stderr)

    STATE.write_text(json.dumps({
        "card": str(path), "at": datetime.now().isoformat(timespec="seconds"),
        "total": len(picked), "added": added, "deduped": deduped, "failed": failed,
        "map": mapping,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"完成：新增 {added} · 已存在 {deduped} · 失败 {failed}")
    print("提示：向量化要另跑 `python memlib.py embed --region qq_zone`（需 vec.ENABLED=true）")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

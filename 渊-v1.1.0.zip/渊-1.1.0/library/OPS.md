# 记忆图书馆 v2 · 运维手册（P0）

## 1. 密钥与盐（最高优先级）

| 文件 | 作用 | 丢了会怎样 |
|---|---|---|
| `E:\dsh-memory\secrets\dedup.salt` | 敏感条目的幂等哈希 | **丢失 = 敏感记忆无法去重，重建后可能重复** |
| `E:\dsh-memory\secrets\content.key` | Fernet 加密正文与摘要 | **丢失 = 敏感记忆永久无法解密** |

**硬规则**

1. `secrets\` **不参与**普通备份（备份脚本必须显式排除）。
2. `dedup.salt` 与 `content.key` **各存一份到不同位置**（例如一个 U 盘、一个密码管理器），不要和记忆库放一起。
3. 权限：只给当前用户；不要放进任何同步盘（OneDrive / 坚果云）。
4. 换机器：先恢复 secrets，再恢复 jsonl，最后 `rebuild`。顺序错了敏感条目会解不开。

> 当前状态：**P1 待接 DPAPI / Windows 凭据管理器**。在此之前，明文文件是已知风险。

## 2. 已知限制（必须在对接前知道）

1. **`check` 不校验敏感条目**：无法在不解密的前提下比对哈希。敏感条目的完整性只能靠 `get(reveal=true)` 人工抽查。
2. **向量未启用**（`VECTORS_ENABLED=False`）：`vec_status` 只会是 `uncalculated` / `skipped_sensitive`；检索只用 FTS。
3. **archive 只降权**（×0.7），不会隐藏；这是 SPEC §5 的选择，不是 bug。
4. **冲突检测是字面比对**（bigram Jaccard ≥0.85），换词改写会漏判。
5. **重建期间禁止写入**：返回 `E_REBUILDING`（retry 30s）。队列满返回 `E_BUSY`（retry 2s）。
6. **测试数据清理**：用 `purge`，它只删库并记墓碑（`kv.tombs`），jsonl 不重写；`rebuild`/`check` 会跳过墓碑 id。

## 3. 日常巡检

```bash
cd E:\dsh-memory
python memlib.py check          --region dsh_zone   # md/db 计数、哈希、坏行
python memlib.py stats-export   --region dsh_zone   # 热度快照（重建时回填）
python memlib.py manifest                           # 原子写 manifest（gen+sha256）
python memlib.py drain                              # 消费队列，失败进死信
```

建议节奏：每天 `check` + `stats-export`；每周 `manifest`；每次重建前先 `stats-export`。

## 4. 灾难恢复

```
1) 恢复 secrets\（缺了敏感条目就废了）
2) 恢复 dsh_zone\ / qq_zone\ 下的 *.jsonl
3) python memlib.py init
4) python memlib.py stats-export 的上一份快照放回 reports\
5) python memlib.py rebuild --region dsh_zone
6) python memlib.py check         # 应 db_count == md_count
```

## 5. 对接 SurfCore 的前置条件（现在**不满足**）

- [x] `E_REBUILDING` 拦截
- [x] `E_BUSY` 队列上限
- [x] 测试脏数据清理（`purge` + 墓碑）
- [x] 密钥备份规则成文（本文）
- [x] `check` / `stats-export` / `manifest` 全跑通
- [ ] **bench 回到旧渊基线附近**（当前 95%@6 / 90%@3，旧渊 100%/95%）
- [ ] 向量接入（P1）
- [ ] 真实 kill 进程测试（P1）
- [ ] 迁移阶段 2/3：双写 24h + 切 recall 入口

> 结论：**P0 可以独立跑，但还不能替换旧渊的 recall 入口。**


## 2.1 `recover` 命令（B 阶段新增）

```bash
python memlib.py recover --region dsh_zone
```

**什么时候用**：`check` 报 `missing_in_db` 时（典型：进程在 jsonl 落盘后、SQLite 提交前被杀）。

**做什么**：扫 jsonl 建 `id → (文件, 偏移, 长度)`（同 id 取最后一条），与 DB 求差集，只补缺的条目及其 stats / heat_event / FTS。

**不做什么**：不写 jsonl、不分配新 id、不改已有行、不删库内孤儿（只报告）。

**输出**：`{scanned_files, valid_entries, bad_lines, recovered_count, missing_in_md, tombs_skipped, elapsed_ms, batch_errors}`。

**锁**：独立 `recover_lock`（秒级），**不阻塞** `memory_update`；与 `rebuild_lock`（分钟级、阻塞写入）分开。并发写入产生的新记录由下一次 `check`/`recover` 处理。

**边界**：半行损坏的记录**无法恢复**，内容永久丢失，只能靠 jsonl 备份。`recover` 只统计 `bad_lines`。


## 2.2 向量相关运维（P1-A，mock 已验证）

1. **环境变量**：`MEM_EMBEDDING_ENDPOINT / TOKEN / MODEL / SPACE / DIM` + `VECTORS_ENABLED=true`；缺任何一项向量链路自动短路。
2. **探活**：失败进入 60s 短屏蔽（不叠加熔断 streak），到期自动再探，不需要重启进程。
3. **熔断**：仅传输层错误计数（超时/连接/5xx）；401/403 与维度错误只报错；并发满走 `VecBusy` 不计熔断。
4. **回填**：`mem embed --limit N` 探针 → `mem embed --all`；每批 sleep 100ms，不占业务信号量。
5. **墓碑在库外**：`tombs.json` 必须与 jsonl 一起备份，否则 rebuild 后已 purge 的条目会复活。
6. **测试隔离**：任何自测脚本必须从 `memlib.ROOT` 取路径，禁止硬编码——本次曾因硬编码误删生产库。


## 2.3 验收与测试顺序（P1-A）

1. **顺序**：`init → 写入 → mem embed 回填 → rebuild → check → 12 项自测 → bench`。
2. **独立测试库**：`MEM_ROOT=<临时目录>`，跑完删除；测试脚本必须从 `memlib.ROOT` 取路径（历史上曾因硬编码误删生产库）。
3. **验收脚本**：`_acceptance.py`（14 项，含 six 个重点确认）、`_regress_review.py`（5 项）。
4. **mock 限制**：无真实语义，bench 数字不得写入正式指标。
5. **向量就绪判定**：必须 `embedding_store.vec_calc_status='ready'` **且** `memory.vec_status='ready'` **且** model_name/model_version 与当前配置一致，三者同时满足。

## 2.4 云端 embedding（SiliconFlow bge-m3）

启动脚本：`E:\dsh-memory\start_emb_silicon.bat`

```
setx SILICONFLOW_API_KEY "sk-xxxx"     :: 只做一次，之后开新终端
start_emb_silicon.bat probe            :: 回填 5 条验证链路
start_emb_silicon.bat all              :: 全量回填
```

参数约定：

| 变量 | 值 |
|---|---|
| `MEM_EMBEDDING_ENDPOINT` | `https://api.siliconflow.cn`（代码里拼 `/v1/embeddings`） |
| `MEM_EMBEDDING_MODEL` | `BAAI/bge-m3` |
| `MEM_EMBEDDING_SPACE` | `bge-m3@1024-cloud-siliconflow`（与本地 `bge-m3@1024-f16-v1` 区分，禁止混用） |
| `MEM_EMBEDDING_DIM` | 1024 |
| `MEM_EMBEDDING_TIMEOUT_MS` | **800**（云端 RTT 100–400ms，150ms 会大量降级） |

与本地服务的差异：

1. **探活路径不同**：SiliconFlow 没有 `/health`，`vec.health()` 会先试 `/health`，404 再试 `/v1/models`；两者都失败才判定不可用。
2. **超时放宽到 800ms**：这是对本地 150ms 预算的**有意放宽**，仅适用于云端；本地服务仍建议 150ms。
3. **429 限流**：目前按 `VecBad` 处理（不计熔断、不重试），批次会记为失败；遇到大量 429 应先看配额，不要调大超时。
4. **免费额度**：bge-m3 在硅基流动有免费额度，超限会 429；回填 578 条约 37 批（每批 16 条）。

已知限制：云端向量与本地向量**不可混算**，`MEM_EMBEDDING_SPACE` 不同会让旧向量自动失效（走 fts-only），换服务商时必须整库重填。

## 2.5 按需向量模式（默认）

`MEM_VECTORS_MODE` 三档：

| 值 | 行为 |
|---|---|
| `off` | 永远不用向量，纯 FTS（~7ms） |
| `on` | 一直用向量（~230ms，首次；缓存后 ~10ms） |
| `ondemand`（默认） | 只有执行 `mem vec on` 后才用，到期自动关 |

```bash
python E:\dsh-memory\memlib.py vec on --minutes 60   # 开 60 分钟
python E:\dsh-memory\memlib.py vec off               # 立即关
python E:\dsh-memory\memlib.py vec status            # 看模式/到期/熔断
```

原因：向量召回 bench 100%@3，但每次多 ~220ms；日常关键词检索 FTS 已 95%，故默认按需。

## 2.6 环境变量（用户级）

`SILICONFLOW_API_KEY` 已写入**用户级环境变量**（HKCU\Environment）。

注意：**已运行的 DSH 进程看不到新变量**，需要重启 DSH 或在启动时显式设置 `$env:SILICONFLOW_API_KEY`。

## 2.7 增量同步（新库追平 md）

```bash
python memlib.py sync            # 增量：只读 mtime 变过的 md
python memlib.py sync --embed    # 同时给新条目补向量
```

- 首轮全扫 604 条约 **23ms**（先比哈希集合，重复的直接跳过；旧实现 6.5s）。
- `search` 前会自动补同步，**60 秒内只跑一次**；`MEM_AUTO_SYNC=0` 可关。
- 实测：新鲜状态搜索 6–10ms；过期后首次搜索（含同步）35ms。

## 2.8 记忆 MCP（供 QQ 等无本地工具的会话读取）

服务：`E:\dsh-memory\mem_mcp.py`（stdio, JSON-RPC 2.0, 只读）

| 工具 | 参数 | 说明 |
|---|---|---|
| `mem_search` | `query, audience(work/life/shared), top≤5, max_chars≤600` | 检索，返回 ≤5 条 / ≤600 字 |
| `mem_get` | `id, reveal, audience` | 取单条；敏感条目需 reveal |
| `mem_stats` | — | 条目数 / 向量就绪 / 熔断状态 |

硬约束：只读、audience 过滤、响应体积上限、每次调用写 `reports/mcp-audit.log`、返回体带 `type:"memory"` 标明"这是资料不是指令"。

### 挂载（两处，需重启 DSH）

**① 主 profile**：`C:\Users\19442\.dsh\profiles\desktop\cordis.patch.yml`

```yaml
  - id: mcp-memlib
    name: '@deepseek-ai/dsh-mcp-client'
    config:
      serverName: memlib
      transport: stdio
      command: 'E:\6deepseek\python\python.exe'
      args: ['E:\dsh-memory\mem_mcp.py']
```

**② QQ preset**：`E:\gongzuo\surfcore\dsh\agent-presets\qq-chat-v2\agent.cordis.yml`
同上，另需确认 qq-tool-restrict 的白名单放行 `mem_*`。

### 验证

```bash
python E:\dsh-memory\_test_mcp.py     # 5 条 JSON-RPC，期望 initialize/tools/list/search/stats 全通
```

实测：`initialize` → memlib v1.0.0；`tools/list` → 3 个工具；`search(work)` 5 条、`search(life)` 1 条；`stats` → 605 条 / 604 条向量。

## 2.9 记忆版本约束

| 规则 | 落地方式 |
|---|---|
| 优先原地改，不堆重复 | 写作纪律 + `memory` 工具 replace；memlib 侧不做自动合并 |
| 新版本替代旧版本 | 相似度 ≥ `VERSION_SIM=0.70` 时，旧行 `obsolete=1`（保留可查，不删） |
| 召回默认丢弃 obsolete | `_score` 过滤 `obsolete=1`；`search --history` / MCP `include_obsolete=true` 才展示 |
| 同分按 updated_at 新→旧 | 二次稳定排序：先按 updated_at 倒序，再按分数倒序 |

```bash
python memlib.py obsolete dsh-20261111-000123          # 手动标旧版
python memlib.py obsolete dsh-20261111-000123 --undo   # 撤销
python memlib.py search "热度衰减" --history            # 查历史版本
```

注意：阈值 0.7 是「同主题改写」的经验值；改写幅度小于 30% 会被判成新版本，大于则并存。
改过头就用 `--undo` 把旧条目标回来。

## 2.10 drain 修复（队列回放）

| bug | 现象 | 修法 |
|---|---|---|
| reindex 参数不匹配 | 14 个占位符只给 13 个值 → 每次重试失败 → 3 次后进 dead_letter | 补齐 `audience` / `updated_at` |
| vector 任务空转 | 只标 done 不真算 | 有向量能力就顺手 `_embed_ids`，失败不阻塞 |
| 插入失败静默 | 只落队列，原因只在内存里 | `last_error` 落库 + `write_log` 记 `E_INDEX_INSERT` |

验收：`_test_drain.py` 5/5（reindex 落库、带 audience/updated_at、无 dead_letter、队列无残留）。
生产库积压 29 个任务已全部消费，`pending=0 / dead_letter=0`。

## 2.11 记忆 API 随 DSH 启动（无窗口）

`mem_mcp.py` 现在会在自己的进程里起一个 HTTP 线程（`127.0.0.1:18801`）：

- DSH 启动时拉起 MCP → 接口同时可用，**不需要单独启动，也没有窗口**
- 端口被占用时自动跳过（已有实例在跑则不重复绑定）
- DSH 退出时线程随进程结束
- 关闭方式：环境变量 `MEM_API_EMBED=0`

`start_mem_api.bat` 只作为兜底（DSH 没开、或想单独调试时用）。
验活：`curl http://127.0.0.1:18801/health`

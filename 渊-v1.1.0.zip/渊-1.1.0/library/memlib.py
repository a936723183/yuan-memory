#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆图书馆 v2 · P0 实现
========================
按 E:\\dsh-yuan\\SPEC.md 落地：jsonl 真相源 + SQLite 缓存 + 写入队列 + 死信 + 对账 + 迁移导入。
P0 范围：DDL 全部建表、写入主链路（md 先落盘）、检索（任务/创意两种打分降级版）、
        get/check/rebuild/import/stats_export/selftest。
未实现（P1，勿误用）：
  - heat_event_rollup 滚动聚合（表已建，无业务逻辑）
  - embedding_store / retry_vec（VECTORS_ENABLED=False）
  - 检索三档 A/B/C（当前只有 FTS 粗筛 + 单一 sim）
  - compact 离线重排
  - 密钥仍存 secrets/ 本地文件，未接 DPAPI
已知取舍：archive 只降权不隐藏；冲突检测用字面 Jaccard 代偿向量相似度。
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import math
import os
import re
import sqlite3
import sys
import time
import unicodedata
from datetime import datetime, timezone

import vec
from pathlib import Path

# ---------------------------------------------------------------- 配置

ROOT = Path(os.environ.get("MEM_ROOT") or str(Path(__file__).resolve().parent.parent / "data" / "library"))
DB_PATH = ROOT / "memory.db"
MANIFEST = ROOT / "manifest.json"
SECRETS = ROOT / "secrets"
SALT_PATH = SECRETS / "dedup.salt"
KEY_PATH = SECRETS / "content.key"
REPORTS = ROOT / "reports"
TOMB_FILE = ROOT / "tombs.json"
# 记忆源目录（只读）：默认 ~/.dsh/memories
MEM = Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh")) / "memories"

REGIONS = ("dsh_zone", "qq_zone")
MIN_CONTENT = 4          # 小于 4 字直接拒绝（不再静默丢弃）
SIM_FLOOR_VEC = 0.40     # 有向量时的相似度地板
VERSION_SIM = 0.70   # 判定“同一主题的新版本”的相似度门槛
SIM_FLOOR_FTS = 0.25     # 无向量降级模式的地板
QUEUE_MAX = 1000
DAILY_QUOTA = 5000
VECTORS_ENABLED = False  # P1：接上 bge-m3 后改 True
FTS_WINDOW = int(os.environ.get("MEM_FTS_WINDOW", "2000"))  # SPEC §3：摘要 + 原文前 2KB

CJK_RUN = re.compile(r"[\u4e00-\u9fff]+")
LATIN = re.compile(r"[A-Za-z0-9_]{2,}")
LIFE_WORDS = ("喜欢", "感受", "心情", "陪我", "累", "睡", "吃", "生日",
              "称呼", "想我", "开心", "难过", "想你", "礼物", "散步", "聊天")
WORK_WORDS = ("代码", "配置", "接口", "部署", "报错", "脚本", "项目", "编译",
              "依赖", "路径", "端口", "测试", "函数", "数据库", "服务")

QUERY_STOP = ("上次", "那个", "这个", "什么", "怎么", "如何", "为什么", "是不是",
              "可以", "帮我", "请问", "一下", "一些", "我们", "你们", "他们",
              "之前", "刚才", "记得", "还是", "以及", "然后", "就是")


def now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def today_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d")


# ---------------------------------------------------------------- 工具

def classify_audience(text: str) -> str:
    """粗分：生活 / 工作 / 都能看。宁可偏 shared，也不要漏给。"""
    life = sum(text.count(w) for w in LIFE_WORDS)
    work = sum(text.count(w) for w in WORK_WORDS)
    if life and work:
        return "shared"
    if life:
        return "life"
    return "work"


def bigrams(text: str, drop_stop: bool = False) -> list[str]:
    if drop_stop:
        for w in QUERY_STOP:
            text = text.replace(w, " ")
    out, seen = [], set()
    for run in CJK_RUN.findall(text):
        grams = [run[i:i + 2] for i in range(len(run) - 1)] or [run]
        for g in grams:
            if g not in seen:
                seen.add(g); out.append(g)
    for w in LATIN.findall(text):
        w = w.lower()
        if w not in seen:
            seen.add(w); out.append(w)
    return out


def norm(text: str) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", text)).lower()


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def ensure_secrets():
    SECRETS.mkdir(parents=True, exist_ok=True)
    if not SALT_PATH.exists():
        SALT_PATH.write_bytes(os.urandom(32))
    if not KEY_PATH.exists():
        KEY_PATH.write_bytes(base64.urlsafe_b64encode(os.urandom(32)))


def dedup_hash(content: str, sensitive: bool) -> str:
    if not sensitive:
        return sha256(content)
    ensure_secrets()
    return hmac.new(SALT_PATH.read_bytes(), content.encode("utf-8"), hashlib.sha256).hexdigest()


def fernet():
    from cryptography.fernet import Fernet
    ensure_secrets()
    return Fernet(KEY_PATH.read_bytes())


def enc(text: str) -> str:
    return fernet().encrypt(text.encode("utf-8")).decode("ascii")


def dec(token: str) -> str:
    return fernet().decrypt(token.encode("ascii")).decode("utf-8")


# ---------------------------------------------------------------- 表

DDL = """
CREATE TABLE IF NOT EXISTS memory (
  id TEXT PRIMARY KEY,
  region TEXT NOT NULL CHECK(region IN ('dsh_zone','qq_zone')),
  content_abstract TEXT NOT NULL,
  source_path TEXT NOT NULL,
  src_offset INTEGER NOT NULL,
  src_len INTEGER NOT NULL,
  content_sha256 TEXT NOT NULL,
  is_sensitive INTEGER NOT NULL DEFAULT 0,
  keyword_list TEXT,
  alias_list TEXT,
  mem_type TEXT NOT NULL DEFAULT 'normal'
    CHECK(mem_type IN ('config','preference','draft','normal')),
  create_time_utc TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'normal' CHECK(status IN ('normal','deprecated')),
  storage_type TEXT NOT NULL DEFAULT 'normal' CHECK(storage_type IN ('normal','archive')),
  embedding_id TEXT,
  vec_status TEXT NOT NULL DEFAULT 'uncalculated'
    CHECK(vec_status IN ('uncalculated','ready','failed','dead','skipped_sensitive')),
  UNIQUE(region, content_sha256)
);
CREATE INDEX IF NOT EXISTS ix_mem_region_status ON memory(region, status);
CREATE INDEX IF NOT EXISTS ix_mem_region_storage ON memory(region, storage_type);

CREATE TABLE IF NOT EXISTS memory_stats (
  memory_id TEXT PRIMARY KEY,
  hot_score REAL NOT NULL,
  hits INTEGER NOT NULL DEFAULT 0,
  last_access_utc TEXT,
  updated_utc TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS heat_event_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  memory_id TEXT NOT NULL,
  delta REAL NOT NULL,
  event_utc TEXT NOT NULL,
  compacted INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_heat_mem ON heat_event_log(memory_id, event_utc);

CREATE TABLE IF NOT EXISTS heat_event_rollup (
  memory_id TEXT NOT NULL,
  day TEXT NOT NULL,
  net_delta REAL NOT NULL,
  cnt INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY(memory_id, day)
);

CREATE TABLE IF NOT EXISTS embedding_store (
  memory_id TEXT PRIMARY KEY,
  embedding BLOB,
  dim INTEGER,
  model_name TEXT,
  model_version TEXT,
  vec_calc_status TEXT NOT NULL DEFAULT 'uncalculated'
    CHECK(vec_calc_status IN ('uncalculated','ready','failed','dead')),
  updated_utc TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS relation (
  id TEXT PRIMARY KEY,
  region TEXT NOT NULL,
  node_a_id TEXT NOT NULL,
  node_b_id TEXT NOT NULL,
  relation_type TEXT NOT NULL
    CHECK(relation_type IN ('依赖配置','配套素材','版本继承','反向参考','单纯提及')),
  confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
  source TEXT NOT NULL CHECK(source IN ('manual','rule','model')),
  created_utc TEXT NOT NULL,
  UNIQUE(region, node_a_id, node_b_id, relation_type)
);
CREATE INDEX IF NOT EXISTS ix_rel_a ON relation(node_a_id);
CREATE INDEX IF NOT EXISTS ix_rel_b ON relation(node_b_id);

CREATE TABLE IF NOT EXISTS synonym (
  origin_text TEXT NOT NULL,
  alias_text TEXT NOT NULL,
  PRIMARY KEY(origin_text, alias_text)
);

CREATE TABLE IF NOT EXISTS write_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts_utc TEXT NOT NULL,
  region TEXT NOT NULL,
  action TEXT NOT NULL,
  memory_id TEXT,
  content_len INTEGER,
  result TEXT NOT NULL CHECK(result IN ('ok','deduped','rejected','error')),
  error_code TEXT,
  ms INTEGER
);

CREATE TABLE IF NOT EXISTS write_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts_utc TEXT NOT NULL,
  region TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'pending'
    CHECK(state IN ('pending','doing','done','failed')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT
);

CREATE TABLE IF NOT EXISTS dead_letter (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  memory_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('vector','index','md')),
  reason TEXT,
  payload TEXT,
  ts_utc TEXT NOT NULL,
  resolved INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS seq_alloc (
  region TEXT NOT NULL,
  day TEXT NOT NULL,
  seq INTEGER NOT NULL,
  PRIMARY KEY(region, day)
);

CREATE TABLE IF NOT EXISTS kv (
  k TEXT PRIMARY KEY,
  v TEXT
);

-- 附加（SPEC 未列出，检索需要）：FTS 索引表
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(id UNINDEXED, big, tokenize='unicode61');
"""


class MemError(Exception):
    def __init__(self, code: str, message: str = "", retry_after_ms: int | None = None):
        self.code, self.message, self.retry_after_ms = code, message, retry_after_ms


def connect() -> sqlite3.Connection:
    ROOT.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(DDL)
    try:
        cols = {r[1] for r in db.execute("PRAGMA table_info(memory)")}
        if "audience" not in cols:
            db.execute("ALTER TABLE memory ADD COLUMN audience TEXT NOT NULL DEFAULT 'work'")
        if "obsolete" not in cols:
            db.execute("ALTER TABLE memory ADD COLUMN obsolete INTEGER NOT NULL DEFAULT 0")
        if "updated_at" not in cols:
            db.execute("ALTER TABLE memory ADD COLUMN updated_at TEXT")
        db.commit()
    except Exception:
        pass
    return db


def kv_get(db, key, default=None):
    row = db.execute("SELECT v FROM kv WHERE k=?", (key,)).fetchone()
    return row["v"] if row else default


def kv_set(db, key, value):
    db.execute("INSERT OR REPLACE INTO kv(k,v) VALUES(?,?)", (key, str(value)))


# ---------------------------------------------------------------- 写入

def _append_jsonl(region: str, record: dict) -> tuple[str, int, int]:
    day = today_utc()
    rel = f"{region}/{day}.jsonl"
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n"
    crash = os.environ.get("MEM_TEST_CRASH", "")
    if crash == "jsonl_half":  # 只写半行就硬杀，模拟 kill -9
        with path.open("ab") as fb:
            fb.write(line.encode("utf-8")[: max(1, len(line) // 2)])
            fb.flush()
            os.fsync(fb.fileno())
        os._exit(9)
    with path.open("a", encoding="utf-8", newline="\n") as f:
        # 修复上次崩溃留下的半行：先补一个换行，避免新记录接在坏行后面
        if f.tell() > 0:
            with path.open("rb") as rb:
                rb.seek(-1, 2)
                if rb.read(1) != b"\n":
                    f.write("\n")
        offset = f.tell()
        f.write(line)
        f.flush()
        os.fsync(f.fileno())
    if crash == "after_jsonl":  # 真相源已落盘、库还没写：模拟 kill -9
        os._exit(9)
    return rel, offset, len(line.encode("utf-8"))


def _alloc_id(db, region: str) -> str:
    day = today_utc()
    row = db.execute("SELECT seq FROM seq_alloc WHERE region=? AND day=?", (region, day)).fetchone()
    seq = (row["seq"] if row else 0) + 1
    db.execute("INSERT OR REPLACE INTO seq_alloc(region,day,seq) VALUES(?,?,?)", (region, day, seq))
    prefix = region.replace("_zone", "")
    return f"{prefix}-{day}-{seq:06d}"


def _log(db, region, action, mem_id, clen, result, code=None, ms=None):
    db.execute(
        "INSERT INTO write_log(ts_utc,region,action,memory_id,content_len,result,error_code,ms)"
        " VALUES(?,?,?,?,?,?,?,?)",
        (now_utc(), region, action, mem_id, clen, result, code, ms))


def _quota_ok(db, region) -> bool:
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    row = db.execute(
        "SELECT COUNT(*) c FROM write_log WHERE region=? AND action='update' AND result IN ('ok','deduped')"
        " AND ts_utc LIKE ?", (region, today + "%")).fetchone()
    return row["c"] < DAILY_QUOTA


def _similar(a: str, b: str) -> float:
    ga, gb = set(bigrams(a[:2000])), set(bigrams(b[:2000]))
    if not ga or not gb:
        return 0.0
    return len(ga & gb) / len(ga | gb)


def memory_update(region: str, content: str, mem_type: str = "normal",
                  is_sensitive: bool = False, keyword_list: str = "") -> dict:
    t0 = time.time()
    if region not in REGIONS:
        raise MemError("E_INVALID", f"未知 region: {region}")
    if mem_type not in ("config", "preference", "draft", "normal"):
        raise MemError("E_INVALID", f"未知 mem_type: {mem_type}")
    content = (content or "").strip()
    if len(norm(content)) < MIN_CONTENT:
        raise MemError("E_INVALID", f"原文太短（<{MIN_CONTENT} 字），拒绝写入")

    db = connect()
    try:
        if kv_get(db, "rebuild_lock") == "1":
            raise MemError("E_REBUILDING", "库正在重建，暂不接受写入", retry_after_ms=30000)
        if db.execute("SELECT COUNT(*) c FROM write_queue WHERE state='pending'").fetchone()["c"] >= QUEUE_MAX:
            raise MemError("E_BUSY", "写入队列已满", retry_after_ms=2000)
        if not _quota_ok(db, region):
            raise MemError("E_QUOTA", "单日写入超限")

        digest = dedup_hash(content, is_sensitive)
        row = db.execute("SELECT id,status FROM memory WHERE region=? AND content_sha256=?",
                         (region, digest)).fetchone()
        if row:
            revived = row["status"] == "deprecated"
            if revived:  # 同一内容重新写入：把废弃条目复活，而不是新建一条
                db.execute("UPDATE memory SET status='normal' WHERE id=?", (row["id"],))
                db.execute("UPDATE memory_stats SET hot_score=0.5,updated_utc=? WHERE memory_id=?",
                           (now_utc(), row["id"]))
                db.execute("INSERT INTO heat_event_log(memory_id,delta,event_utc) VALUES(?,?,?)",
                           (row["id"], 0.5, now_utc()))
            _log(db, region, "update", row["id"], len(content), "deduped", None,
                 int((time.time() - t0) * 1000))
            db.commit()
            return {"id": row["id"], "deduped": True, "revived": revived,
                    "vec_status": "uncalculated", "stored_in_db": True}

        abstract = content[:160] + ("…" if len(content) > 160 else "")
        mem_id = _alloc_id(db, region)
        record = {
            "id": mem_id, "region": region, "mem_type": mem_type,
            "is_sensitive": bool(is_sensitive), "create_time_utc": now_utc(),
            "content_sha256": digest,
            "abstract": enc(abstract) if is_sensitive else abstract,
            "content": enc(content) if is_sensitive else content,
        }
        # 1) 真相源先落盘（fsync 成功才算成功）
        rel, offset, length = _append_jsonl(region, record)

        # 2) 写库；失败 → pending_index，不影响成功
        pending_index = False
        try:
            db.execute(
                "INSERT INTO memory(id,region,content_abstract,source_path,src_offset,src_len,"
                "content_sha256,is_sensitive,keyword_list,alias_list,mem_type,create_time_utc,"
                "status,storage_type,embedding_id,vec_status,audience,updated_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'normal','normal',NULL,?,?,?)",
                (mem_id, region, record["abstract"], rel, offset, length, digest,
                 int(is_sensitive), keyword_list, None, mem_type, record["create_time_utc"],
                 "skipped_sensitive" if is_sensitive else "uncalculated",
                 classify_audience(content), now_utc()))
            db.execute("INSERT INTO memory_stats(memory_id,hot_score,hits,updated_utc)"
                       " VALUES(?,?,0,?)", (mem_id, 1.0 if mem_type == "config" else 0.5, now_utc()))
            db.execute("INSERT INTO heat_event_log(memory_id,delta,event_utc) VALUES(?,?,?)",
                       (mem_id, 1.0 if mem_type == "config" else 0.5, now_utc()))
            # 非敏感：进 FTS（摘要 + 前 2KB 正文）
            if not is_sensitive:
                body = abstract + " " + content[:FTS_WINDOW]
                db.execute("INSERT INTO memory_fts(id,big) VALUES(?,?)",
                           (mem_id, " ".join(bigrams(body))))
            # 冲突检测（无向量时用字面相似度代偿）
            if not is_sensitive:
                for other in db.execute(
                        "SELECT * FROM memory WHERE region=? AND status='normal' AND is_sensitive=0"
                        " AND id<>? ORDER BY id DESC LIMIT 30", (region, mem_id)).fetchall():
                    try:
                        old_text = _read_source(other)
                        if _similar(content, old_text) >= VERSION_SIM:
                            # 版本约束：旧版标 obsolete（保留可查），不删不 deprecate
                            db.execute("UPDATE memory SET obsolete=1 WHERE id=?",
                                       (other["id"],))
                            db.execute("UPDATE memory_stats SET hot_score=0 WHERE memory_id=?",
                                       (other["id"],))
                            db.execute("UPDATE relation SET node_a_id=? WHERE node_a_id=?",
                                       (mem_id, other["id"]))
                            db.execute("UPDATE relation SET node_b_id=? WHERE node_b_id=?",
                                       (mem_id, other["id"]))
                    except Exception as exc:
                        _log(db, region, "update", mem_id, len(content), "error",
                             "E_CONFLICT_CHECK:" + type(exc).__name__)
            # 向量任务入队（P0 不计算，先入队等待 P1）
            db.execute("INSERT INTO write_queue(ts_utc,region,payload_json,state,attempts)"
                       " VALUES(?,?,?,'pending',0)",
                       (now_utc(), region, json.dumps({"action": "vector", "id": mem_id})))
            _log(db, region, "update", mem_id, len(content), "ok", None,
                 int((time.time() - t0) * 1000))
            db.commit()
        except Exception as exc:  # 库失败：转 pending_index
            db.rollback()
            db.execute("INSERT INTO write_queue(ts_utc,region,payload_json,state,attempts,last_error)"
                       " VALUES(?,?,?,'pending',0,?)",
                       (now_utc(), region,
                        json.dumps({"action": "reindex", "id": mem_id, "record": record, "source_path": rel, "src_offset": offset, "src_len": length}),
                        str(exc)[:200]))
            db.commit()
            pending_index = True

        return {"id": mem_id, "deduped": False,
                "vec_status": "skipped_sensitive" if is_sensitive else "uncalculated",
                "stored_in_db": not pending_index, "pending_index": pending_index}
    finally:
        db.close()


# ---------------------------------------------------------------- 读取

def memory_get(region: str, mem_id: str, reveal: bool = False) -> dict:
    db = connect()
    try:
        row = db.execute("SELECT * FROM memory WHERE region=? AND id=?", (region, mem_id)).fetchone()
        if not row:
            raise MemError("E_INVALID", "没有这条记忆")
        sensitive = bool(row["is_sensitive"])
        abstract = row["content_abstract"]
        if sensitive:
            abstract = dec(abstract) if reveal else "[敏感内容，需授权]"
        out = {"id": row["id"], "abstract": abstract, "mem_type": row["mem_type"],
               "status": row["status"], "storage_type": row["storage_type"],
               "vec_status": row["vec_status"], "sensitive_locked": sensitive and not reveal}
        if reveal and not sensitive:
            out["content"] = _read_source(row)
        elif reveal and sensitive:
            out["content"] = _read_source(row)
        db.execute("UPDATE memory_stats SET hits=hits+1,last_access_utc=?,updated_utc=?"
                   " WHERE memory_id=?", (now_utc(), now_utc(), mem_id))
        db.execute("INSERT INTO heat_event_log(memory_id,delta,event_utc) VALUES(?,?,?)",
                   (mem_id, 0.15, now_utc()))
        db.commit()
        return out
    finally:
        db.close()


def _read_source(row) -> str:
    path = ROOT / row["source_path"]
    with path.open("rb") as f:
        f.seek(row["src_offset"])
        raw = f.read(row["src_len"])
    line = raw.decode("utf-8").strip()
    obj = json.loads(line)
    body = obj.get("content", "")
    return dec(body) if obj.get("is_sensitive") else body


def _score(db, region, query, mode, top_k, include_sensitive, audience=None, include_obsolete=False):
    toks = bigrams(query, drop_stop=True)[:24]
    if not toks:
        return []
    match = " OR ".join('"%s"' % t.replace('"', '""') for t in toks)
    rows = db.execute(
        "SELECT id, bm25(memory_fts) AS s FROM memory_fts WHERE memory_fts MATCH ? ORDER BY s LIMIT 60",
        (match,)).fetchall()
    if not rows:
        return []

    n = len(rows)
    total = db.execute("SELECT COUNT(*) c FROM memory WHERE region=?", (region,)).fetchone()["c"] or 1
    weights = {}
    for tk in toks:
        try:
            df = db.execute("SELECT COUNT(*) c FROM memory_fts WHERE memory_fts MATCH ?",
                            ('"%s"' % tk.replace('"', '""'),)).fetchone()["c"]
        except sqlite3.OperationalError:
            df = 0
        weights[tk] = math.log(1.0 + total / max(1, df))
    wsum = sum(weights.values()) or 1.0

    cands = []          # [(row, fts_score)]
    for i, r in enumerate(rows):
        row = db.execute("SELECT * FROM memory WHERE id=?", (r["id"],)).fetchone()
        if not row or row["status"] != "normal":
            continue
        if row["is_sensitive"] and not include_sensitive:
            continue
        if not include_obsolete and row["obsolete"]:
            continue
        if audience:
            allowed = {audience, "shared"}
            if (row["audience"] or "work") not in allowed:
                continue
        try:
            body_text = row["content_abstract"] if row["is_sensitive"] else _read_source(row)
        except Exception:
            body_text = row["content_abstract"]
        dgrams = set(bigrams(body_text))
        hit_w = sum(w for tk, w in weights.items() if tk in dgrams)
        cov = hit_w / wsum
        fts_score = float(os.environ.get("MEM_SIM_RANK", "0.6")) * (1 - i / max(1, n)) + \
            (1 - float(os.environ.get("MEM_SIM_RANK", "0.6"))) * cov
        if fts_score < SIM_FLOOR_FTS:
            continue
        cands.append((row, fts_score))
    if not cands:
        return []

    # 两步独立 min-max 融合（fts 全候选 / cos 仅 ready 子集），缺向量半权
    fused = vec.fuse(db, region, query, [(row["id"], f) for row, f in cands])

    out = []
    for row, f in cands:
        sim, source = fused.get(row["id"], (vec.FALLBACK * f, "fts-only"))
        st = db.execute("SELECT hot_score FROM memory_stats WHERE memory_id=?",
                        (row["id"],)).fetchone()
        heat = min(1.0, st["hot_score"]) if st else 0.0
        try:
            days = (datetime.now(timezone.utc)
                    - datetime.strptime(row["create_time_utc"], "%Y-%m-%dT%H:%M:%SZ")
                    .replace(tzinfo=timezone.utc)).days
        except Exception:
            days = 0
        fresh = math.exp(-max(0, days) / 120.0)
        rel = _rel(db, row["id"]) if mode == "creative" else 0.0
        if mode == "creative":
            score = 0.4 * sim + 0.2 * heat + 0.1 * fresh + 0.3 * rel
        else:
            score = 0.7 * sim + 0.2 * heat + 0.1 * fresh
        if row["storage_type"] == "archive":
            score *= 0.7
        out.append({"id": row["id"], "abstract": row["content_abstract"],
                    "score": round(score, 3), "track": row["mem_type"],
                    "sensitive": bool(row["is_sensitive"]),
                    "sim": round(sim, 3), "source": source,
                    "obsolete": bool(row["obsolete"]),
                    "_u": row["updated_at"] or row["create_time_utc"]})
    # 同相似度按 updated_at 新→旧（版本优先）：先按时间倒序，再按分数稳定排序
    out.sort(key=lambda x: x.get("_u") or "", reverse=True)
    out.sort(key=lambda x: -x["score"])
    for o in out:
        o.pop("_u", None)
    return out[:top_k]


def _rel(db, mem_id) -> float:
    rows = db.execute(
        "SELECT confidence FROM relation WHERE (node_a_id=? OR node_b_id=?)"
        " AND relation_type<>'单纯提及' AND confidence>=0.5", (mem_id, mem_id)).fetchall()
    return max((min(1.0, r["confidence"]) for r in rows), default=0.0)


def _mem_files():
    out = []
    d = MEM / "daily"
    if d.exists():
        out += sorted(d.glob("*.md"))
    p = MEM / "projects"
    if p.exists():
        out += sorted(p.glob("*/*.md"))
    for n in ("MEMORY.md", "USER.md"):
        f = MEM / n
        if f.exists():
            out.append(f)
    return out


def cmd_sync(args):
    """增量同步：只读 mtime 变过的 md，去重导入；向量窗口开着时顺带补向量。"""
    db = connect()
    t0 = time.time()
    try:
        last = float(kv_get(db, "sync_last_ts", "0") or 0)
    finally:
        db.close()
    changed = []
    for f in _mem_files():
        try:
            if f.stat().st_mtime > last:
                changed.append(f)
        except Exception:
            pass
    # 先取现有哈希，重复的直接跳过（避免逐条开事务，首轮从 6.5s 降到百毫秒级）
    db = connect()
    try:
        known = {r["content_sha256"] for r in db.execute(
            "SELECT content_sha256 FROM memory WHERE region=?", (args.region,))}
        tombs = tombs_read(db)
    finally:
        db.close()

    added = deduped = entries = failed = 0
    for f in changed:
        if f.name == "KEY.md":
            mt = "config"
        elif f.name == "USER.md":
            mt = "preference"
        else:
            mt = "normal"
        try:
            texts = parse_old_md(f)
        except Exception:
            continue
        for text in texts:
            entries += 1
            h = dedup_hash(text, False)
            if h in known:
                deduped += 1
                continue
            try:
                r = memory_update(args.region, text, mem_type=mt)
                known.add(h)
                if r.get("deduped"):
                    deduped += 1
                else:
                    added += 1
            except Exception:
                failed += 1

    embedded = 0
    if args.embed and vec.ENABLED:
        db = connect()
        try:
            rows = db.execute(
                "SELECT id FROM memory WHERE region=? AND is_sensitive=0 AND vec_status<>'ready'"
                " LIMIT 500", (args.region,)).fetchall()
        finally:
            db.close()
        batch = []
        for r in rows:
            batch.append(r["id"])
            if len(batch) >= 16:
                embedded += _embed_ids(batch)
                batch = []
        if batch:
            embedded += _embed_ids(batch)

    db = connect()
    try:
        kv_set(db, "sync_last_ts", str(time.time()))
        db.commit()
    finally:
        db.close()
    out = {"files": len(changed), "entries": entries, "added": added,
           "deduped": deduped, "failed": failed, "embedded": embedded,
           "ms": int((time.time() - t0) * 1000)}
    if not args.quiet:
        print(json.dumps(out, ensure_ascii=False))
    return 0


def _embed_ids(ids):
    db = connect()
    try:
        texts = []
        keep = []
        for mid in ids:
            row = db.execute("SELECT * FROM memory WHERE id=?", (mid,)).fetchone()
            try:
                texts.append(_read_source(row))
                keep.append(mid)
            except Exception:
                pass
        if not texts:
            return 0
        vs = vec.embed(texts, db, use_cache=False, use_sem=False)
        for mid, v in zip(keep, vs):
            vec.upsert_vector(db, mid, v)
        db.commit()
        return len(keep)
    except Exception:
        return 0
    finally:
        db.close()


def _maybe_sync(region="dsh_zone"):
    """search 前自动补同步：60 秒内只跑一次；MEM_AUTO_SYNC=0 可关。"""
    if os.environ.get("MEM_AUTO_SYNC", "1") == "0":
        return
    db = connect()
    try:
        last = float(kv_get(db, "sync_last_ts", "0") or 0)
    finally:
        db.close()
    if time.time() - last < 60:
        return
    try:
        cmd_sync(argparse.Namespace(region=region, embed=False, quiet=True))
    except Exception:
        pass


def memory_search(region, query, mode="task", top_k=6, include_sensitive=False,
                  audience=None, include_obsolete=False):
    _maybe_sync(region)
    db = connect()
    try:
        hits = _score(db, region, query, mode, min(top_k, 10), include_sensitive, audience,
                      include_obsolete)
        for h in hits:
            if h["sensitive"]:
                h["abstract"] = "[敏感内容，需授权]"
        db.commit()
        return hits
    finally:
        db.close()


# ---------------------------------------------------------------- 维护

def tombs_read(db) -> set:
    """墓碑存库外：rebuild 会清库，存库内会让被 purge 的条目复活。"""
    out = set()
    try:
        if TOMB_FILE.exists():
            out |= set(json.loads(TOMB_FILE.read_text(encoding="utf-8")))
    except Exception:
        pass
    try:
        out |= set(json.loads(kv_get(db, "tombs", "[]")))
    except Exception:
        pass
    return out


def tombs_write(db, ids: set):
    kv_set(db, "tombs", json.dumps(sorted(ids)))
    try:
        TOMB_FILE.write_text(json.dumps(sorted(ids), ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def purge(region: str, ids: list[str]) -> dict:
    """删除测试/错误条目：清库 + 记墓碑；jsonl 不重写（真相源只追加）。"""
    db = connect()
    try:
        removed = 0
        for mid in ids:
            row = db.execute("SELECT id FROM memory WHERE region=? AND id=?", (region, mid)).fetchone()
            db.execute("DELETE FROM memory WHERE id=?", (mid,))
            db.execute("DELETE FROM memory_stats WHERE memory_id=?", (mid,))
            db.execute("DELETE FROM heat_event_log WHERE memory_id=?", (mid,))
            db.execute("DELETE FROM memory_fts WHERE id=?", (mid,))
            db.execute("DELETE FROM embedding_store WHERE memory_id=?", (mid,))
            if row:
                removed += 1
        tombs = tombs_read(db)
        tombs |= set(ids)
        tombs_write(db, tombs)
        _log(db, region, "purge", ",".join(ids)[:80], None, "ok")
        db.commit()
        return {"requested": len(ids), "removed": removed, "tombs": len(tombs)}
    finally:
        db.close()


def check(region) -> dict:
    db = connect()
    try:
        md_ids, md_bad = set(), []
        for path in sorted((ROOT / region).glob("*.jsonl")):
            with path.open("r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                        md_ids.add(obj["id"])
                    except Exception:
                        md_bad.append(str(path))
        db_ids = {r["id"] for r in db.execute("SELECT id FROM memory WHERE region=?", (region,))}
        mismatch = []
        for row in db.execute("SELECT * FROM memory WHERE region=? AND is_sensitive=0", (region,)):
            try:
                body = _read_source(row)
                if sha256(body) != row["content_sha256"]:
                    mismatch.append(row["id"])
            except Exception:
                mismatch.append(row["id"])
        tombs = tombs_read(db)
        md_ids -= tombs
        # 三类向量一致性检测
        store = {r["memory_id"]: r["model_version"] for r in db.execute(
            "SELECT memory_id, model_version FROM embedding_store")}
        orphans = sorted(i for i in store if i not in db_ids)[:20]
        ready_no_vec = [r["id"] for r in db.execute(
            "SELECT id FROM memory WHERE region=? AND vec_status='ready'", (region,))
            if r["id"] not in store][:20]
        vec_not_ready = []
        for mid, ver in store.items():
            if ver != vec.SPACE or mid not in db_ids:
                continue
            row = db.execute("SELECT vec_status FROM memory WHERE id=?", (mid,)).fetchone()
            if row and row["vec_status"] != "ready":
                vec_not_ready.append(mid)
        return {"md_count": len(md_ids), "db_count": len(db_ids),
                "vector_orphans": orphans, "ready_without_vector": ready_no_vec,
                "vector_without_ready": vec_not_ready[:20],
                "missing_in_db": sorted(md_ids - db_ids)[:20],
                "missing_in_md": sorted(db_ids - md_ids)[:20],
                "bad_lines": md_bad, "hash_mismatch": mismatch}
    finally:
        db.close()


def recover(region: str) -> dict:
    """急救：扫 jsonl 与 DB 的差集，只补 SQLite 缓存，不改真相源、不分配新 id。"""
    import time as _t
    t0 = _t.time()
    db = connect()
    try:
        kv_set(db, "recover_lock", "1")
        db.commit()
        latest = {}          # id -> (rel, offset, len)  最后一条生效
        scanned_files = 0
        bad = 0
        for path in sorted((ROOT / region).glob("*.jsonl")):
            scanned_files += 1
            rel = f"{region}/{path.name}"
            with path.open("rb") as f:
                offset = 0
                for raw in f:
                    length = len(raw)
                    try:
                        obj = json.loads(raw.decode("utf-8"))
                        latest[obj["id"]] = (rel, offset, length)
                    except Exception:
                        bad += 1
                    offset += length

        db_ids = {r["id"] for r in db.execute(
            "SELECT id FROM memory WHERE region=?", (region,))}
        tombs = tombs_read(db)
        missing = [i for i in latest if i not in db_ids]
        missing_in_md = sorted(db_ids - set(latest) - tombs)

        stats = {}
        snap = ROOT / "reports" / f"stats-{region}.json"
        if snap.exists():
            try:
                stats = json.loads(snap.read_text(encoding="utf-8"))
            except Exception:
                stats = {}

        recovered = 0
        errors = []
        batch = 0
        for mid in missing:
            rel, offset, length = latest[mid]
            try:
                with (ROOT / rel).open("rb") as f:
                    f.seek(offset)
                    obj = json.loads(f.read(length).decode("utf-8"))
                st = stats.get(mid, {})
                heat = float(st.get("hot_score", 0.5))
                hits = int(st.get("hits", 0))
                db.execute(
                    "INSERT OR IGNORE INTO memory(id,region,content_abstract,source_path,src_offset,"
                    "src_len,content_sha256,is_sensitive,keyword_list,alias_list,mem_type,"
                    "create_time_utc,status,storage_type,embedding_id,vec_status)"
                    " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'normal','normal',NULL,?)",
                    (mid, region, obj.get("abstract", ""), rel, offset, length,
                     obj.get("content_sha256", ""), int(bool(obj.get("is_sensitive"))),
                     None, None, obj.get("mem_type", "normal"),
                     obj.get("create_time_utc", now_utc()),
                     "skipped_sensitive" if obj.get("is_sensitive") else "uncalculated"))
                db.execute("INSERT OR REPLACE INTO memory_stats(memory_id,hot_score,hits,updated_utc)"
                           " VALUES(?,?,?,?)", (mid, heat, hits, now_utc()))
                db.execute("INSERT INTO heat_event_log(memory_id,delta,event_utc) VALUES(?,?,?)",
                           (mid, heat, now_utc()))
                if not obj.get("is_sensitive"):
                    body = obj.get("abstract", "") + " " + str(obj.get("content", ""))[:FTS_WINDOW]
                    db.execute("DELETE FROM memory_fts WHERE id=?", (mid,))
                    db.execute("INSERT INTO memory_fts(id,big) VALUES(?,?)",
                               (mid, " ".join(bigrams(body))))
                recovered += 1
                batch += 1
                if batch >= 200:
                    db.commit()
                    batch = 0
            except Exception as exc:
                errors.append(f"{mid}:{type(exc).__name__}")
        _log(db, region, "recover", None, None, "ok",
             None, int((_t.time() - t0) * 1000))
        db.commit()
        return {"scanned_files": scanned_files, "valid_entries": len(latest),
                "bad_lines": bad, "recovered_count": recovered,
                "missing_in_md": missing_in_md[:20], "tombs_skipped": len(tombs),
                "elapsed_ms": int((_t.time() - t0) * 1000), "batch_errors": errors[:10]}
    finally:
        try:
            db.execute("UPDATE kv SET v='0' WHERE k='recover_lock'")
            db.commit()
        except Exception:
            pass
        db.close()


def rebuild(region) -> dict:
    db = connect()
    try:
        kv_set(db, "rebuild_lock", "1")
        db.commit()
        stats = {}
        snap = ROOT / "reports" / f"stats-{region}.json"
        if snap.exists():
            stats = json.loads(snap.read_text(encoding="utf-8"))
        rebuilt = skipped = 0
        tombs = tombs_read(db)
        for path in sorted((ROOT / region).glob("*.jsonl")):
            with path.open("rb") as f:
                offset = 0
                for raw in f:
                    length = len(raw)
                    try:
                        obj = json.loads(raw.decode("utf-8"))
                    except Exception:
                        offset += length
                        skipped += 1
                        continue
                    mid = obj["id"]
                    if mid in tombs:
                        skipped += 1
                        offset += length
                        continue
                    db.execute(
                        "INSERT OR REPLACE INTO memory(id,region,content_abstract,source_path,src_offset,"
                        "src_len,content_sha256,is_sensitive,keyword_list,alias_list,mem_type,"
                        "create_time_utc,status,storage_type,embedding_id,vec_status)"
                        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (mid, region, obj.get("abstract", ""), f"{region}/{path.name}", offset, length,
                         obj.get("content_sha256", ""), int(bool(obj.get("is_sensitive"))),
                         None, None, obj.get("mem_type", "normal"), obj.get("create_time_utc", now_utc()),
                         "normal", "normal", None,
                         "skipped_sensitive" if obj.get("is_sensitive") else "uncalculated"))
                    heat = stats.get(mid, {}).get("hot_score", 0.5)
                    db.execute("INSERT OR REPLACE INTO memory_stats(memory_id,hot_score,hits,updated_utc)"
                               " VALUES(?,?,?,?)", (mid, heat, stats.get(mid, {}).get("hits", 0), now_utc()))
                    if not obj.get("is_sensitive"):
                        body = obj.get("abstract", "") + " " + str(obj.get("content", ""))[:FTS_WINDOW]
                        db.execute("DELETE FROM memory_fts WHERE id=?", (mid,))
                        db.execute("INSERT INTO memory_fts(id,big) VALUES(?,?)",
                                   (mid, " ".join(bigrams(body))))
                    rebuilt += 1
                    offset += length
        # 重建后恢复 seq_alloc，否则 id 会从头撞车
        db.execute("DELETE FROM seq_alloc")
        for r in db.execute("SELECT id, region FROM memory").fetchall():
            try:
                _prefix, day, seq_str = r["id"].split("-")
                region_name = r["region"]
                seq_num = int(seq_str)
                cur = db.execute("SELECT seq FROM seq_alloc WHERE region=? AND day=?",
                                 (region_name, day)).fetchone()
                db.execute("INSERT OR REPLACE INTO seq_alloc(region,day,seq) VALUES(?,?,?)",
                           (region_name, day, max(seq_num, cur["seq"] if cur else 0)))
            except Exception:
                continue
        # 清掉墓碑记录（purge 过的），否则 rebuild 后库与 md 数量永久对不上
        try:
            tombs = tombs_read(db)
            if tombs:
                marks = ",".join("?" * len(tombs))
                db.execute(f"DELETE FROM memory WHERE id IN ({marks})", list(tombs))
                db.execute(f"DELETE FROM memory_stats WHERE memory_id IN ({marks})", list(tombs))
                db.execute(f"DELETE FROM embedding_store WHERE memory_id IN ({marks})", list(tombs))
        except Exception:
            pass
        # rebuild 从 jsonl 重建，jsonl 不存 audience → 重建后统一重分类
        try:
            for _r in db.execute("SELECT id,content_abstract FROM memory WHERE region=?",
                                 (region,)).fetchall():
                db.execute("UPDATE memory SET audience=? WHERE id=?",
                           (classify_audience(_r["content_abstract"]), _r["id"]))
        except Exception:
            pass
        # 按 embedding_store + 版本匹配恢复 vec_status（否则重建后向量全废）
        db.execute("UPDATE memory SET vec_status='ready' WHERE id IN ("
                   "SELECT memory_id FROM embedding_store WHERE model_name=? AND model_version=?)",
                   (vec.MODEL, vec.SPACE))
        kv_set(db, "rebuild_lock", "0")
        db.commit()
        return {"scanned": rebuilt + skipped, "rebuilt": rebuilt, "skipped": skipped, "mismatched": 0}
    finally:
        db.close()


def stats_export(region) -> str:
    db = connect()
    try:
        data = {r["memory_id"]: {"hot_score": r["hot_score"], "hits": r["hits"],
                                 "last_access_utc": r["last_access_utc"]}
                for r in db.execute(
                    "SELECT s.* FROM memory_stats s JOIN memory m ON m.id=s.memory_id WHERE m.region=?",
                    (region,))}
        REPORTS.mkdir(parents=True, exist_ok=True)
        path = REPORTS / f"stats-{region}.json"
        path.write_text(json.dumps(data, ensure_ascii=False, indent=0), encoding="utf-8")
        return str(path)
    finally:
        db.close()


def write_manifest():
    ROOT.mkdir(parents=True, exist_ok=True)
    files = {}
    for region in REGIONS:
        d = ROOT / region
        if d.exists():
            for p in sorted(d.glob("*.jsonl")):
                files[f"{region}/{p.name}"] = {
                    "bytes": p.stat().st_size,
                    "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                }
    gen = 1
    if MANIFEST.exists():
        try:
            gen = json.loads(MANIFEST.read_text(encoding="utf-8")).get("gen", 1) + 1
        except Exception:
            gen = 1
    payload = {"gen": gen, "updated_utc": now_utc(), "files": files}
    payload["self_sha256"] = sha256(json.dumps(files, sort_keys=True, ensure_ascii=False))
    tmp = MANIFEST.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, MANIFEST)  # 同卷原子替换
    return gen


def drain(limit=50) -> dict:
    db = connect()
    try:
        rows = db.execute("SELECT * FROM write_queue WHERE state='pending' ORDER BY id LIMIT ?",
                          (limit,)).fetchall()
        done = failed = 0
        for r in rows:
            payload = json.loads(r["payload_json"])
            try:
                if payload["action"] == "vector":
                    # 有向量能力就顺手算掉；失败也不阻塞（后续 embed --all 可补）
                    mid = payload.get("id")
                    if vec.ENABLED and mid:
                        try:
                            _embed_ids([mid])
                        except Exception:
                            pass
                    db.execute("UPDATE write_queue SET state='done' WHERE id=?", (r["id"],))
                elif payload["action"] == "reindex":
                    rec = payload["record"]
                    db.execute(
                        "INSERT OR REPLACE INTO memory(id,region,content_abstract,source_path,src_offset,"
                        "src_len,content_sha256,is_sensitive,keyword_list,alias_list,mem_type,"
                        "create_time_utc,status,storage_type,embedding_id,vec_status,"
                        "audience,updated_at)"
                        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'normal','normal',NULL,?,?,?)",
                        (rec["id"], rec["region"], rec["abstract"],
                         payload.get("source_path", ""), payload.get("src_offset", 0),
                         payload.get("src_len", 0), rec["content_sha256"],
                         int(rec["is_sensitive"]), None, None, rec["mem_type"], rec["create_time_utc"],
                         "uncalculated", classify_audience(rec["abstract"]),
                         rec["create_time_utc"]))
                    db.execute("UPDATE write_queue SET state='done' WHERE id=?", (r["id"],))
                else:
                    raise ValueError("unknown action")
                done += 1
            except Exception as exc:
                attempts = (r["attempts"] or 0) + 1
                state = "failed" if attempts >= 3 else "pending"
                db.execute("UPDATE write_queue SET attempts=?,state=?,last_error=? WHERE id=?",
                           (attempts, state, str(exc)[:200], r["id"]))
                if state == "failed":
                    db.execute("INSERT INTO dead_letter(memory_id,kind,reason,payload,ts_utc)"
                               " VALUES(?,?,?,?,?)",
                               (json.loads(r["payload_json"]).get("id", "?"), "index",
                                str(exc)[:200], r["payload_json"], now_utc()))
                failed += 1
        db.commit()
        return {"done": done, "failed": failed, "pending": db.execute(
            "SELECT COUNT(*) c FROM write_queue WHERE state='pending'").fetchone()["c"]}
    finally:
        db.close()


# ---------------------------------------------------------------- 迁移

def parse_old_md(path: Path):
    raw = path.read_text(encoding="utf-8", errors="replace")
    chunks, cur = [], []
    for line in raw.splitlines():
        if line.strip() == "§":
            chunks.append("\n".join(cur)); cur = []
        else:
            cur.append(line)
    chunks.append("\n".join(cur))
    out = []
    for c in chunks:
        c = c.strip()
        if not c:
            continue
        c = re.sub(r"^\[\d{4}-\d{2}-\d{2}( \d{2}:\d{2})?\]\s*", "", c)
        c = re.sub(r"^\[\d{2}:\d{2}\]\s*\[[^\]]*\]\s*", "", c)
        if len(norm(c)) >= MIN_CONTENT:
            out.append(c)
    return out


def import_old(from_dir: str, region: str = "dsh_zone", dry_run: bool = False) -> dict:
    src = Path(from_dir)
    files = []
    src = src.expanduser()
    if (src / "daily").exists():
        files += sorted((src / "daily").glob("*.md"))
    if (src / "projects").exists():
        files += sorted((src / "projects").glob("*/*.md"))
    for name in ("MEMORY.md", "USER.md"):
        if (src / name).exists():
            files.append(src / name)
    total = dup = bad = 0
    imported = []
    for f in files:
        if f.name == "KEY.md":
            mem_type = "config"
        elif f.name == "USER.md":
            mem_type = "preference"
        else:
            mem_type = "normal"
        for text in parse_old_md(f):
            total += 1
            if dry_run:
                continue
            try:
                res = memory_update(region, text, mem_type=mem_type)
                imported.append(res["id"])
                if res["deduped"]:
                    dup += 1
            except MemError:
                bad += 1
            except Exception:
                bad += 1
    report = {"total": total, "imported": len(imported), "dup": dup, "hash_mismatch": 0,
              "failed": bad, "files": len(files), "dry_run": dry_run}
    REPORTS.mkdir(parents=True, exist_ok=True)
    path = REPORTS / f"import_report-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    report["report_path"] = str(path)
    return report


# ---------------------------------------------------------------- 入口

def cmd_embed(args):
    if args.all and args.limit:
        raise SystemExit("--all 与 --limit 不能同时指定")
    db = connect()
    try:
        if not vec.ENABLED:
            print("VECTORS_ENABLED 未开启，拒绝回填")
            return 2
        limit = -1 if args.all else (args.limit or 5)
        sql = ("SELECT id FROM memory WHERE region=? AND is_sensitive=0 AND vec_status<>'ready'"
               " ORDER BY id")
        if limit > 0:
            rows = db.execute(sql + " LIMIT ?", (args.region, limit)).fetchall()
        else:
            rows = db.execute(sql, (args.region,)).fetchall()
        total, done, failed = len(rows), 0, 0
        t0 = time.time()
        BATCH = 16
        for start in range(0, total, BATCH):
            chunk = rows[start:start + BATCH]
            texts, ids = [], []
            for r in chunk:
                row = db.execute("SELECT * FROM memory WHERE id=?", (r["id"],)).fetchone()
                try:
                    texts.append(_read_source(row))
                    ids.append(r["id"])
                except Exception:
                    failed += 1
            if texts:
                try:
                    vs = vec.embed(texts, db, use_cache=False, use_sem=False)
                    for mid, v in zip(ids, vs):
                        vec.upsert_vector(db, mid, v)
                    db.commit()
                    done += len(ids)
                except vec.VecAuth as e:
                    print(f"鉴权失败，中止：{e}")
                    return 3
                except Exception as e:
                    failed += len(ids)
                    print(f"批次失败：{type(e).__name__}: {e}")
            if total and (start + BATCH) % 50 == 0:
                print(f"已处理 {min(start + BATCH, total)}/{total}，失败 {failed}，"
                      f"用时 {time.time() - t0:.0f}s")
            time.sleep(0.1)
        print(f"回填完成：成功 {done}，失败 {failed}，共 {total}，用时 {time.time() - t0:.1f}s")
        return 0
    finally:
        db.close()


def _lock_guard():
    """名字写死为「渊」：清单或目录被改名 → 自锁 + 焚毁索引（记忆源不动）。"""
    if any(a in ("unlock", "doctor") for a in sys.argv[1:]):
        return
    try:
        from name_lock import enforce_name
    except Exception:
        return
    enforce_name(Path(__file__).resolve().parent.parent)


def main():
    _lock_guard()
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass
    ap = argparse.ArgumentParser(prog="mem", description="记忆图书馆 v2")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init")
    p = sub.add_parser("update"); p.add_argument("content"); p.add_argument("--region", default="dsh_zone")
    p.add_argument("--type", default="normal"); p.add_argument("--sensitive", action="store_true")
    p = sub.add_parser("search"); p.add_argument("query"); p.add_argument("--region", default="dsh_zone")
    p.add_argument("--mode", default="task"); p.add_argument("--top", type=int, default=6)
    p.add_argument("--sensitive", action="store_true")
    p = sub.add_parser("get"); p.add_argument("id"); p.add_argument("--region", default="dsh_zone")
    p.add_argument("--reveal", action="store_true")
    p = sub.add_parser("check"); p.add_argument("--region", default="dsh_zone")
    p = sub.add_parser("rebuild"); p.add_argument("--region", default="dsh_zone")
    p = sub.add_parser("stats-export"); p.add_argument("--region", default="dsh_zone")
    p = sub.add_parser("import"); p.add_argument("from_dir"); p.add_argument("--region", default="dsh_zone")
    p.add_argument("--dry-run", action="store_true")
    p = sub.add_parser("drain"); p.add_argument("--limit", type=int, default=50)
    sub.add_parser("manifest")
    p = sub.add_parser("selftest"); p.add_argument("--region", default="dsh_zone")
    p = sub.add_parser("purge"); p.add_argument("ids"); p.add_argument("--region", default="dsh_zone")
    p = sub.add_parser("recover"); p.add_argument("--region", default="dsh_zone")
    p = sub.add_parser("obsolete"); p.add_argument("id")
    p.add_argument("--undo", action="store_true"); p.add_argument("--region", default="dsh_zone")
    p = sub.add_parser("audience"); p.add_argument("--apply", action="store_true")
    p.add_argument("--region", default="dsh_zone")
    p = sub.add_parser("sync"); p.add_argument("--region", default="dsh_zone")
    p.add_argument("--embed", action="store_true"); p.add_argument("--quiet", action="store_true")
    p = sub.add_parser("vec"); p.add_argument("action", choices=["on", "off", "status"])
    p.add_argument("--minutes", type=int, default=60)
    p = sub.add_parser("embed"); p.add_argument("--region", default="dsh_zone")
    p.add_argument("--all", action="store_true"); p.add_argument("--limit", type=int, default=None)

    a = ap.parse_args()
    if a.cmd == "init":
        db = connect(); db.close(); write_manifest(); print("init ok", DB_PATH)
    elif a.cmd == "update":
        print(json.dumps(memory_update(a.region, a.content, a.type, a.sensitive), ensure_ascii=False))
    elif a.cmd == "search":
        for h in memory_search(a.region, a.query, a.mode, a.top, a.sensitive):
            print(f"{h['score']:.2f} [{h['id']}] {h['abstract'][:60]}")
    elif a.cmd == "get":
        print(json.dumps(memory_get(a.region, a.id, a.reveal), ensure_ascii=False)[:800])
    elif a.cmd == "obsolete":
        db = connect()
        db.execute("UPDATE memory SET obsolete=? WHERE id=? AND region=?",
                   (0 if a.undo else 1, a.id, a.region))
        db.commit()
        row = db.execute("SELECT id,obsolete FROM memory WHERE id=?", (a.id,)).fetchone()
        db.close()
        print(json.dumps({"id": row["id"] if row else a.id,
                          "obsolete": row["obsolete"] if row else None}, ensure_ascii=False))
    elif a.cmd == "audience":
        db = connect()
        rows = db.execute("SELECT id,content_abstract,audience FROM memory WHERE region=?",
                          (a.region,)).fetchall()
        counts = {}
        changed = 0
        for r in rows:
            tag = classify_audience(r["content_abstract"])
            counts[tag] = counts.get(tag, 0) + 1
            if a.apply and r["audience"] != tag:
                db.execute("UPDATE memory SET audience=? WHERE id=?", (tag, r["id"]))
                changed += 1
        if a.apply:
            db.commit()
        db.close()
        print(json.dumps({"apply": a.apply, "changed": changed, "counts": counts},
                         ensure_ascii=False))
    elif a.cmd == "sync":
        return cmd_sync(a)
    elif a.cmd == "vec":
        import vec as _v
        db = connect()
        try:
            if a.action == "on":
                until = time.time() + a.minutes * 60
                _v._kv_set(db, "vec_ondemand_until", str(until))
                db.commit()
                print(f"向量已开启，{a.minutes} 分钟后自动关闭（until "
                      f"{time.strftime('%H:%M:%S', time.localtime(until))}）")
            elif a.action == "off":
                _v._kv_set(db, "vec_ondemand_until", "0")
                db.commit()
                print("向量已关闭（走纯 FTS）")
            else:
                until = _v.ondemand_until(db)
                active = time.time() < until
                print(json.dumps({
                    "enabled": _v.ENABLED, "mode": _v.MODE,
                    "ondemand_active": active,
                    "until": time.strftime("%H:%M:%S", time.localtime(until)) if active else None,
                    "breaker_open": _v.breaker_open(db),
                    "probe_ok": _v._kv_get(db, "vec_probe_ok", "?"),
                }, ensure_ascii=False))
        finally:
            db.close()
    elif a.cmd == "embed":
        return cmd_embed(a)
    elif a.cmd == "recover":
        print(json.dumps(recover(a.region), ensure_ascii=False))
    elif a.cmd == "purge":
        print(json.dumps(purge(a.region, [x for x in a.ids.split(",") if x]), ensure_ascii=False))
    elif a.cmd == "check":
        print(json.dumps(check(a.region), ensure_ascii=False)[:1200])
    elif a.cmd == "rebuild":
        print(json.dumps(rebuild(a.region), ensure_ascii=False))
    elif a.cmd == "stats-export":
        print(stats_export(a.region))
    elif a.cmd == "import":
        print(json.dumps(import_old(a.from_dir, a.region, a.dry_run), ensure_ascii=False))
    elif a.cmd == "drain":
        print(json.dumps(drain(a.limit), ensure_ascii=False))
    elif a.cmd == "manifest":
        print("gen", write_manifest())
    elif a.cmd == "selftest":
        import runpy
        runpy.run_path(str(ROOT / "_selftest.py"), run_name="__main__")
    return 0


if __name__ == "__main__":
    sys.exit(main())

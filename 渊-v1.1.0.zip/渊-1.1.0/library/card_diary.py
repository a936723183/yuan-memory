# -*- coding: utf-8 -*-
"""给角色写一条「今日日记」，走记忆卡的 inbox 通道。

为什么走 inbox 而不是直接改 memory-card.json：
    卡的唯一写者是对应的宿主插件；外部直接写会和它的读-改-写抢，可能把整张卡覆盖回去。
    memory-inbox.jsonl 就是留给外部写入者的通道，宿主下一次整理会把它并进卡里
    （变成她的一条 self 记忆：她说过的话，带时间、带衰减）。

用法：
    python card_diary.py --text "今天……"          # 追加一条今日日记
    python card_diary.py --text "……" --dry-run     # 只看会写什么
    python card_diary.py --show                    # 看今天有没有写过
一天一条；重复调用会被拒绝（除非 --force）。
"""
import argparse
import glob
import json
import os
import sys
from datetime import datetime
from pathlib import Path

DSH_HOME = Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))
CARD_GLOB = str(DSH_HOME / "surfcore" / "characters" / "*" / "memory" / "memory-card.json")
MAX_CHARS = 480  # 宿主的 redactForMemory 对 qq scope 截到 500，留点余量


def inbox_path(card: Path) -> Path:
    return card.parent / "memory-inbox.jsonl"


def pick_card(explicit: str = "") -> Path:
    if explicit:
        return Path(explicit)
    paths = sorted(Path(p) for p in glob.glob(CARD_GLOB))
    if not paths:
        sample = Path(__file__).resolve().parent.parent / 'samples' / 'memory-card.sample.json'
        if sample.exists():
            return sample
        raise SystemExit(f"没有找到记忆卡：{CARD_GLOB}")
    return max(paths, key=lambda p: p.stat().st_mtime)


def today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def has_today(inbox: Path) -> bool:
    if not inbox.exists():
        return False
    day = today()
    try:
        for line in inbox.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                o = json.loads(line)
            except Exception:
                continue
            if o.get("kind") == "diary" and str(o.get("at", ""))[:10] == day:
                return True
    except OSError:
        pass
    return False


def _lock_guard():
    """名字写死为「渊」：清单或目录被改名 → 自锁 + 焚毁索引（记忆源不动）。"""
    if any(a in ("unlock", "doctor") for a in sys.argv[1:]):
        return
    try:
        from name_lock import enforce_name
    except Exception:
        return
    enforce_name(Path(__file__).resolve().parent.parent)


def main() -> int:
    _lock_guard()
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="写一条角色日记（inbox 通道）")
    ap.add_argument("--text", default="")
    ap.add_argument("--card", default="")
    ap.add_argument("--at", default="", help="ISO 时间，默认现在")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    card = pick_card(args.card)
    inbox = inbox_path(card)

    if args.show:
        print(f"卡：{card}")
        print(f"inbox：{inbox}（今天{'已' if has_today(inbox) else '还没有'}日记）")
        return 0

    text = " ".join(str(args.text or "").split()).strip()
    if not text:
        print("需要 --text", file=sys.stderr)
        return 2
    if not text.startswith("【日记】"):
        text = "【日记】" + text
    if len(text) > MAX_CHARS:
        text = text[: MAX_CHARS - 1] + "…"

    if has_today(inbox) and not args.force:
        print("今天已经写过一条日记了（加 --force 可再写）", file=sys.stderr)
        return 3

    line = {
        "text": text,
        "at": args.at or datetime.now().astimezone().isoformat(timespec="seconds"),
        "senderId": "self",
        "sender": "渊",
        "isSelf": True,
        "isOwner": False,
        "private": True,
        "direct": True,
        "conversationKey": "diary",
        "platform": "qq",
        "kind": "diary",
    }

    if args.dry_run:
        print(json.dumps(line, ensure_ascii=False))
        return 0

    inbox.parent.mkdir(parents=True, exist_ok=True)
    with inbox.open("a", encoding="utf-8") as f:
        f.write(json.dumps(line, ensure_ascii=False) + "\n")
    print(f"已写入：{inbox}")
    print("宿主下一次整理（≤10 分钟）会把它并进记忆卡。")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mock embedding 服务：确定性（crc32）、近似语义（bigram 哈希），支持 401/500/超时。"""
import json
import math
import os
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DIM = int(os.environ.get("MOCK_DIM", "1024"))
MODE = os.environ.get("MOCK_MODE", "ok")          # ok | 401 | 500 | timeout
TOKEN = os.environ.get("MOCK_TOKEN", "")
PORT = int(os.environ.get("MOCK_PORT", "18777"))
# 说明：bias 对不同长度文本的相似度影响不一致（短文本整体偏高、长文本接近 0），
# 这是 mock 的已知限制，只用于跑通管线，不代表真实语义分布。
BIAS = 0.35


def _tokens(text: str):
    out, run = [], []
    for ch in text:
        if "\u4e00" <= ch <= "\u9fff":
            run.append(ch)
        else:
            if len(run) >= 2:
                out += [run[i] + run[i + 1] for i in range(len(run) - 1)]
            elif run:
                out.append(run[0])
            run = []
    if len(run) >= 2:
        out += [run[i] + run[i + 1] for i in range(len(run) - 1)]
    for w in text.replace("　", " ").split():
        if w.isascii() and len(w) >= 2:
            out.append(w.lower())
    return out


def embed_one(text: str):
    vec = [0.0] * DIM
    for t in _tokens(text):
        h = zlib.crc32(t.encode("utf-8"))          # 确定性：跨进程/重启不变
        vec[h % DIM] += 1.0 if (h >> 16) & 1 else -1.0
    for i in range(DIM):
        vec[i] += BIAS / math.sqrt(DIM)
    n = math.sqrt(sum(x * x for x in vec)) or 1.0
    return [x / n for x in vec]


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/health", "/v1/health"):
            if MODE == "401":
                return self._json(401, {"error": "unauthorized"})
            return self._json(200, {"ok": True, "mode": MODE, "dim": DIM})
        if self.path == "/v1/models":
            return self._json(200, {"object": "list", "data": [
                {"id": "bge-m3", "object": "model", "owned_by": "mock"}]})
        self._json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/v1/embeddings":
            return self._json(404, {"error": "not found"})
        if MODE == "timeout":
            time.sleep(1.0)
            return self._json(200, {"data": []})
        if MODE in ("401", "500"):
            return self._json(int(MODE), {"error": "mock failure"})
        if TOKEN:
            if self.headers.get("Authorization", "") != "Bearer " + TOKEN:
                return self._json(401, {"error": "bad token"})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            req = json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return self._json(400, {"error": "bad json"})
        inp = req.get("input")
        texts = [inp] if isinstance(inp, str) else list(inp or [])
        data = [{"object": "embedding", "index": i, "embedding": embed_one(t)}
                for i, t in enumerate(texts)]
        self._json(200, {"object": "list", "model": req.get("model", "mock"),
                         "data": data, "usage": {"prompt_tokens": 0, "total_tokens": 0}})


if __name__ == "__main__":
    print(f"mock embedding on 127.0.0.1:{PORT} mode={MODE} dim={DIM}", flush=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    srv.allow_reuse_address = True
    srv.serve_forever()
